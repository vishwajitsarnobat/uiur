# -*- coding: utf-8 -*-
"""validate.py -- independent audit of raw_spans.jsonl. Recomputes everything
from the text, never trusting the generator."""
import json
import re
import itertools
import math
from collections import Counter, defaultdict

import lexicon as L
from generate import INTENT_ENTITIES, INTENT_ORDER

ROWS = [json.loads(l) for l in open("raw_spans.jsonl", encoding="utf-8")]
FAIL, WARN, OUT = [], [], []


def say(s=""):
    OUT.append(s)


def fail(tag, detail):
    FAIL.append("%-34s %s" % (tag, detail))


def warn(tag, detail):
    WARN.append("%-34s %s" % (tag, detail))


# closed-set surface inventories, as they appear in text
CCY_SURFACES = {}
for code, spec in L.CURRENCIES.items():
    for t in ("code", "word", "sym"):
        for s in spec.get(t, []):
            CCY_SURFACES[s] = code
METHOD_SURFACES = {}
for canon, spec in L.METHODS.items():
    for form in spec["forms"]:
        METHOD_SURFACES[form[0]] = canon

ACC_SET = {a for a, _, _ in L.ACCOUNTS}
ACC_FAMILY = {a: f for a, _, f in L.ACCOUNTS}
BEN_SET = set(L.BENEFICIARIES)
TPL_SET = set(L.TEMPLATES)
AMT_SET = set(L.AMOUNTS)


def occurrences(text, needle):
    """word-boundary-ish occurrences (works for '$', '5,000', 'A/C ...')"""
    out, i = [], 0
    while True:
        j = text.find(needle, i)
        if j < 0:
            return out
        before = text[j - 1] if j else " "
        after = text[j + len(needle)] if j + len(needle) < len(text) else " "
        lb = not (before.isalnum() and needle[0].isalnum())
        rb = not (after.isalnum() and needle[-1].isalnum())
        if lb and rb:
            out.append(j)
        i = j + 1


# ===================================================== 1. structural integrity
dupes = Counter(r["input"] for r in ROWS)
for t, c in dupes.items():
    if c > 1:
        fail("DUPLICATE_SENTENCE", "x%d %s" % (c, t))

label_of_string = defaultdict(set)
for r in ROWS:
    txt, intent = r["input"], r["intent"]
    seen_ranges = []
    for sp in r["spans"]:
        if txt[sp["start"]:sp["end"]] != sp["text"]:
            fail("OFFSET_MISMATCH", txt)
        if sp["label"] not in INTENT_ENTITIES[intent]:
            fail("LABEL_NOT_IN_INTENT_SCHEMA", "%s / %s" % (intent, sp["label"]))
        if len(occurrences(txt, sp["text"])) != 1:
            fail("AMBIGUOUS_SPAN_STRING", "%r in %s" % (sp["text"], txt))
        for a, b in seen_ranges:
            if sp["start"] < b and a < sp["end"]:
                fail("OVERLAPPING_SPANS", txt)
        seen_ranges.append((sp["start"], sp["end"]))
        label_of_string[sp["text"]].add(sp["label"])
        if sp["text"] != sp["text"].strip():
            fail("SPAN_WHITESPACE", repr(sp["text"]))
    if Counter(sp["label"] for sp in r["spans"]).most_common(1)[:1] and \
       max(Counter(sp["label"] for sp in r["spans"]).values(), default=0) > 1:
        fail("REPEATED_LABEL_IN_SENTENCE", txt)

# Role ambiguity is deliberate (see lexicon.DUAL_*): a string is allowed to
# carry more than one label, but ONLY if it comes from a declared dual pool and
# every member of that pool shows the SAME role profile. Identical profiles are
# what stop the model treating one surface as a special case -- the generalised
# form of the "CHAPS was labelled 16/18 times" failure.
DUAL_POOLS = {"bank": (set(L.DUAL_BANK), ("account", "beneficiary")),
              "org": (set(L.DUAL_ORG), ("beneficiary", "template_name"))}
role_counts = defaultdict(Counter)
for r in ROWS:
    for sp in r["spans"]:
        role_counts[sp["text"]][sp["label"]] += 1
for st, labs in label_of_string.items():
    if len(labs) == 1:
        continue
    pool = next((n for n, (m, _) in DUAL_POOLS.items() if st in m), None)
    if pool is None:
        fail("UNDECLARED_AMBIGUOUS_STRING", "%r -> %s" % (st, labs))
    elif set(labs) != set(DUAL_POOLS[pool][1]):
        fail("DUAL_STRING_WRONG_ROLES", "%r -> %s" % (st, labs))
for name, (members, roles) in DUAL_POOLS.items():
    profiles = {tuple(role_counts[m][r] for r in roles) for m in members}
    if len(profiles) != 1:
        fail("DUAL_POOL_PROFILE_NOT_UNIFORM", "%s -> %s" % (name, sorted(profiles)))
    # every member must actually be exercised in BOTH roles
    for m in members:
        if any(role_counts[m][r] == 0 for r in roles):
            fail("DUAL_STRING_UNUSED_ROLE", "%r %s" % (m, dict(role_counts[m])))

# ===================================================== 2. definition conformance
for r in ROWS:
    for sp in r["spans"]:
        v, lab = sp["text"], sp["label"]
        if lab == "account" and v not in ACC_SET:
            fail("ACCOUNT_NOT_IN_LEXICON", v)
        if lab == "beneficiary" and v not in BEN_SET:
            fail("BENEFICIARY_NOT_IN_LEXICON", v)
        if lab == "template_name" and v not in TPL_SET:
            fail("TEMPLATE_NOT_IN_LEXICON", v)
        if lab == "amount" and v not in AMT_SET:
            fail("AMOUNT_NOT_IN_LEXICON", v)
        if lab == "currency" and v not in CCY_SURFACES:
            fail("CURRENCY_NOT_CLOSED_SET", v)
        if lab == "method" and v not in METHOD_SURFACES:
            fail("METHOD_NOT_CLOSED_SET", v)
        if lab == "account" and v.split()[0].lower() in ("my", "our", "the", "a"):
            fail("ACCOUNT_INCLUDES_DETERMINER", v)
        if lab == "amount" and not (any(c.isdigit() for c in v) or v in L.AMOUNTS_WORD):
            fail("AMOUNT_WITHOUT_QUANTITY", v)

# ============================== 3. closed-set leakage (the #1 failure mode)
leak = Counter()
for r in ROWS:
    txt = r["input"]
    covered = [(sp["start"], sp["end"]) for sp in r["spans"]]
    inside = lambda i, n: any(a <= i and i + n <= b for a, b in covered)
    for surf in itertools.chain(CCY_SURFACES, METHOD_SURFACES):
        for i in occurrences(txt, surf):
            if not inside(i, len(surf)):
                leak[(r["intent"], surf)] += 1
                fail("UNLABELLED_CLOSED_SET_TOKEN", "%s | %r | %s" % (r["intent"], surf, txt))

# methods must not exist at all outside intents that allow them
for r in ROWS:
    if "method" in INTENT_ENTITIES[r["intent"]]:
        continue
    for surf in METHOD_SURFACES:
        if occurrences(r["input"], surf):
            fail("METHOD_TOKEN_IN_WRONG_INTENT", "%s | %r | %s" % (r["intent"], surf, r["input"]))

# currency/amount must not exist at all in ACCOUNT_BALANCE except inside account
for r in ROWS:
    if r["intent"] != "ACCOUNT_BALANCE":
        continue
    covered = [(sp["start"], sp["end"]) for sp in r["spans"]]
    for m in re.finditer(r"\d", r["input"]):
        if not any(a <= m.start() < b for a, b in covered):
            fail("DIGIT_OUTSIDE_SPAN_IN_BALANCE", r["input"])

# template wording confined to PAY_FROM_TEMPLATE
for r in ROWS:
    if r["intent"] != "PAY_FROM_TEMPLATE" and re.search(r"\btemplates?\b", r["input"], re.I):
        fail("TEMPLATE_WORD_IN_WRONG_INTENT", r["input"])
# account wording confined to intents that allow the account slot
for r in ROWS:
    if "account" not in INTENT_ENTITIES[r["intent"]] and re.search(r"\baccounts?\b", r["input"], re.I):
        fail("ACCOUNT_WORD_IN_WRONG_INTENT", r["input"])

# ===================================================== 4. balance / distribution
say("=" * 78)
say("DATASET AUDIT   (%d examples)" % len(ROWS))
say("=" * 78)

by_intent = defaultdict(list)
for r in ROWS:
    by_intent[r["intent"]].append(r)

say("\n[1] intent balance")
for it in INTENT_ORDER:
    say("    %-20s %5d" % (it, len(by_intent[it])))

say("\n[2] entity marginals  (target: exactly 50%% of the intent)")
for it in INTENT_ORDER:
    row = []
    for e in INTENT_ENTITIES[it]:
        n = sum(1 for r in by_intent[it] if any(s["label"] == e for s in r["spans"]))
        row.append("%s=%d" % (e, n))
        if n != len(by_intent[it]) // 2:
            fail("MARGINAL_NOT_HALF", "%s %s %d" % (it, e, n))
    say("    %-20s %s" % (it, "  ".join(row)))

say("\n[3] entity-subset coverage  (every combination equally represented)")
for it in INTENT_ORDER:
    c = Counter(tuple(sorted(s["label"] for s in r["spans"])) for r in by_intent[it])
    ents = INTENT_ENTITIES[it]
    expect = [tuple(sorted(x)) for k in range(len(ents) + 1) for x in itertools.combinations(ents, k)]
    missing = [e for e in expect if e not in c]
    if missing:
        fail("SUBSET_MISSING", "%s %s" % (it, missing))
    say("    %-20s %d distinct subsets, counts %s"
        % (it, len(c), sorted(set(c.values()))))

say("\n[4] pairwise co-occurrence  (target: n/4 in each of the 4 cells)")
for it in INTENT_ORDER:
    ents = INTENT_ENTITIES[it]
    if len(ents) < 2:
        continue
    worst = 0
    for a, b in itertools.combinations(ents, 2):
        cell = Counter()
        for r in by_intent[it]:
            labs = {s["label"] for s in r["spans"]}
            cell[(a in labs, b in labs)] += 1
        worst = max(worst, max(abs(v - len(by_intent[it]) / 4) for v in cell.values()))
    say("    %-20s max deviation from n/4: %.1f" % (it, worst))
    if worst > 2:
        fail("PAIRWISE_IMBALANCE", "%s dev=%.1f" % (it, worst))

say("\n[5] closed-set VALUE counts per intent")
for it in INTENT_ORDER:
    if "currency" not in INTENT_ENTITIES[it]:
        continue
    c = Counter(CCY_SURFACES[s["text"]] for r in by_intent[it] for s in r["spans"] if s["label"] == "currency")
    say("    %-20s currency %s" % (it, dict(sorted(c.items()))))
    if len(set(c.values())) != 1:
        fail("CURRENCY_VALUE_IMBALANCE", "%s %s" % (it, dict(c)))
c = Counter(METHOD_SURFACES[s["text"]] for r in ROWS for s in r["spans"] if s["label"] == "method")
say("    %-20s method   %s" % ("NEW_PAYMENT", dict(sorted(c.items()))))
if max(c.values()) - min(c.values()) > 1:
    fail("METHOD_VALUE_IMBALANCE", str(dict(c)))

say("\n[6] cross-intent parity of every currency value")
for code in L.CCY_CODES:
    per = {it: sum(1 for r in by_intent[it] for s in r["spans"]
                   if s["label"] == "currency" and CCY_SURFACES[s["text"]] == code)
           for it in INTENT_ORDER if "currency" in INTENT_ENTITIES[it]}
    say("    %-6s %s" % (code, per))
    if len(set(per.values())) != 1:
        fail("CURRENCY_CROSS_INTENT_IMBALANCE", "%s %s" % (code, per))

say("\n[7] open-set surface usage (min/max per intent)")
for label, lex, intents in [
        ("account", ACC_SET, [i for i in INTENT_ORDER if "account" in INTENT_ENTITIES[i]]),
        ("beneficiary", BEN_SET, [i for i in INTENT_ORDER if "beneficiary" in INTENT_ENTITIES[i]]),
        ("template_name", TPL_SET, ["PAY_FROM_TEMPLATE"]),
        ("amount", AMT_SET, [i for i in INTENT_ORDER if "amount" in INTENT_ENTITIES[i]])]:
    for it in intents:
        c = Counter(s["text"] for r in by_intent[it] for s in r["spans"] if s["label"] == label)
        miss = len(lex) - len(c)
        say("    %-14s %-20s distinct=%d/%d  min=%d max=%d"
            % (label, it, len(c), len(lex), min(c.values(), default=0), max(c.values(), default=0)))
        if miss:
            fail("SURFACE_UNUSED", "%s %s missing %d" % (label, it, miss))
        if label == "account":
            for fam in L.ACCOUNT_FAMILIES:
                v = [n for k, n in c.items() if ACC_FAMILY[k] == fam]
                say("        family %-16s uses=%3d  per-surface min=%d max=%d"
                    % (fam, sum(v), min(v), max(v)))
                if max(v) - min(v) > 1:
                    fail("ACCOUNT_FAMILY_IMBALANCE", "%s %s" % (it, fam))
        elif max(c.values()) - min(c.values()) > 1:
            fail("SURFACE_IMBALANCE", "%s %s spread %d" % (label, it, max(c.values()) - min(c.values())))

say("\n[7b] cross-intent parity: identical count for every open-set surface")
for label in ("account", "beneficiary", "amount"):
    its = [i for i in INTENT_ORDER if label in INTENT_ENTITIES[i]]
    if len(its) < 2:
        continue
    tabs = [Counter(sp["text"] for r in by_intent[i] for sp in r["spans"] if sp["label"] == label)
            for i in its]
    bad = [k for k in tabs[0] if len({t[k] for t in tabs}) != 1]
    say("    %-14s intents=%s  surfaces_with_unequal_counts=%d" % (label, its, len(bad)))
    if bad:
        fail("CROSS_INTENT_SURFACE_PARITY", "%s %s" % (label, bad[:5]))

say("\n[7c] account-family balance is identical in every intent")
for it in [i for i in INTENT_ORDER if "account" in INTENT_ENTITIES[i]]:
    fam = Counter(ACC_FAMILY[sp["text"]] for r in by_intent[it] for sp in r["spans"] if sp["label"] == "account")
    say("    %-20s %s" % (it, dict(sorted(fam.items()))))

say("\n[8] shared skeleton budget (wrappers/frames identical across intents)")
for it in INTENT_ORDER:
    c = Counter(r["meta"]["frame"] for r in by_intent[it])
    pc = Counter(r["meta"]["pattern"] for r in by_intent[it])
    say("    %-20s frames %s   patterns min=%d max=%d" % (it, dict(c), min(pc.values()), max(pc.values())))

say("\n[9] wrapper x subset independence (NEW_PAYMENT, chi-square style)")
for it in INTENT_ORDER:
    cnt = Counter((r["meta"]["pattern"], len(r["meta"]["subset"])) for r in by_intent[it])
    npat = len({p for p, _ in cnt})
    nsz = len({s for _, s in cnt})
    exp = len(by_intent[it]) / (npat * nsz)
    chi = sum((v - exp) ** 2 / exp for v in cnt.values())
    say("    %-20s pattern x |entities|  chi2=%.1f  (dof=%d)" % (it, chi, (npat - 1) * (nsz - 1)))

say("\n[10] hard-negative coverage (decoys that must NEVER be labelled)")
decoys = ["transfer", "payment", "payments", "funds", "money", "fresh", "one-off",
          "amount", "balance", "template", "account", "instruction", "dues", "position"]
for d in decoys:
    tot = sum(len(occurrences(r["input"], d)) for r in ROWS)
    covered = 0
    for r in ROWS:
        cov = [(s["start"], s["end"]) for s in r["spans"]]
        for i in occurrences(r["input"], d):
            if any(a <= i and i + len(d) <= b for a, b in cov):
                covered += 1
    say("    %-12s occurrences=%5d  inside-a-span=%4d  bare-decoy=%5d" % (d, tot, covered, tot - covered))

say("\n[11] minimal-pair probes for the three reported failure modes")
probes = [
    ("generic 'transfer' with NO method label",
     lambda r: bool(occurrences(r["input"], "transfer")) and
               not any(s["label"] == "method" for s in r["spans"])),
    ("'transfer' as part of a real rail",
     lambda r: any(s["label"] == "method" and "transfer" in s["text"] for s in r["spans"])),
    ("rail token + tail noun ('NEFT transfer' -> span=NEFT)",
     lambda r: any(s["label"] == "method" and " " not in s["text"] for s in r["spans"]) and
               bool(occurrences(r["input"], "transfer"))),
    ("denomination inside an account name (not currency)",
     lambda r: any(s["label"] == "account" and s["text"] in L.ACCOUNT_EMBEDDED_CCY for s in r["spans"])),
    ("that account AND a real currency in one sentence",
     lambda r: any(s["label"] == "account" and s["text"] in L.ACCOUNT_EMBEDDED_CCY for s in r["spans"]) and
               any(s["label"] == "currency" for s in r["spans"])),
    ("bare bank name as the account ('from HDFC Bank')",
     lambda r: any(s["label"] == "account" and s["text"] in L.BANKS for s in r["spans"])),
    ("currency present, method absent (NEW_PAYMENT)",
     lambda r: r["intent"] == "NEW_PAYMENT" and
               any(s["label"] == "currency" for s in r["spans"]) and
               not any(s["label"] == "method" for s in r["spans"])),
    ("method present, currency absent (NEW_PAYMENT)",
     lambda r: r["intent"] == "NEW_PAYMENT" and
               any(s["label"] == "method" for s in r["spans"]) and
               not any(s["label"] == "currency" for s in r["spans"])),
    ("'use X' -> method",
     lambda r: any(s["label"] == "method" for s in r["spans"]) and "using" in r["input"]),
    ("'use X' -> currency",
     lambda r: any(s["label"] == "currency" for s in r["spans"]) and "using" in r["input"]),
    ("'use X' -> template_name",
     lambda r: any(s["label"] == "template_name" for s in r["spans"]) and
               re.search(r"\b(use|using)\b", r["input"], re.I) is not None),
    ("template wording but NO template_name span",
     lambda r: r["intent"] == "PAY_FROM_TEMPLATE" and
               not any(s["label"] == "template_name" for s in r["spans"])),
    ("zero-entity examples",
     lambda r: not r["spans"]),
]
for name, fn in probes:
    say("    %-52s %5d" % (name, sum(1 for r in ROWS if fn(r))))

say("\n[11b] pattern x entity coverage (every skeleton seen with AND without each slot)")
thin = 0
for it in INTENT_ORDER:
    for pat in sorted({r["meta"]["pattern"] for r in by_intent[it]}):
        sub = [r for r in by_intent[it] if r["meta"]["pattern"] == pat]
        for e in INTENT_ENTITIES[it]:
            n = sum(1 for r in sub if any(s["label"] == e for s in r["spans"]))
            if min(n, len(sub) - n) < 5:
                thin += 1
                warn("THIN_PATTERN_ENTITY_CELL", "%s p%s %s %d/%d" % (it, pat, e, n, len(sub)))
say("    cells with <5 examples on either side: %d" % thin)

say("\n[12] most intent-discriminative unigrams (manual sanity review)")
tok = defaultdict(Counter)
for r in ROWS:
    for w in set(re.findall(r"[A-Za-z']+", r["input"].lower())):
        tok[w][r["intent"]] += 1
rank = []
for w, c in tok.items():
    tot = sum(c.values())
    if tot < 40:
        continue
    top, n = c.most_common(1)[0]
    rank.append((n / tot, tot, w, top))
rank.sort(reverse=True)
for p, tot, w, top in rank[:18]:
    say("    %-16s %5d occ  %.2f -> %s" % (w, tot, p, top))

say("\n[13] length statistics")
for it in INTENT_ORDER:
    ln = [len(r["input"].split()) for r in by_intent[it]]
    say("    %-20s words min=%d mean=%.1f max=%d" % (it, min(ln), sum(ln) / len(ln), max(ln)))


# ==========================================================================
# 14. CONDITIONAL PROFILE AUDIT  -- the generalised "CHAPS 16/18" check
# ==========================================================================
# Equal totals are not safety. The failure that breaks these models is a value
# whose CONDITIONAL distribution differs from its peers: same count, different
# contexts, or the same context with a different labelling rate. For every
# entity we build each value's profile over intent, pattern, entity subset,
# frame, introducing trigger and surface form, then measure the largest L-inf
# distance between any two peer profiles. Identical peers => the encoder has no
# signal that separates one value from another except the label itself.
DETS = {"the", "a", "an", "my", "our", "your", "this", "that", "same"}
MULTIWORD_TRIGGERS = sorted(
    {t for t in (L.ACC_PREPS + L.BEN_PREPS + L.MET_PREPS + L.AB_PREPS +
                 L.CCY_TRIGGERS + L.PFT_TRIGGERS) if " " in t},
    key=lambda x: -len(x.split()))
say("\n[14] conditional profile divergence (max L-inf between any two peer values)")


def span_context(r, sp):
    pre = r["input"][:sp["start"]].strip().split()
    while pre and pre[-1].lower().strip(",-") in DETS:
        pre = pre[:-1]
    tail = " ".join(w.lower().strip(",-") for w in pre[-4:])
    trig = pre[-1].lower().strip(",-") if pre else "<START>"
    for mw in MULTIWORD_TRIGGERS:
        if tail.endswith(mw):
            trig = mw
            break
    return {
        "intent": r["intent"],
        "pattern": str(r["meta"]["pattern"]),
        "frame": r["meta"]["frame"],
        "subset": ",".join(sorted(x["label"] for x in r["spans"])) or "-",
        "trigger": trig,
        "co_labels": ",".join(sorted({x["label"] for x in r["spans"]} - {sp["label"]})) or "-",
    }


PROFILE_DIMS = ["intent", "pattern", "frame", "subset", "trigger", "co_labels"]

# Peers must be linguistically interchangeable before their profiles can be
# compared. "HDFC Bank" is never preceded by "the" and "the current account"
# always is -- that is grammar, not a skew -- so accounts are compared inside
# their family. Case and surface-form variants collapse onto their canonical
# value, because the form mix is itself balanced in section [17].
PERSONS = set(L.BENEFICIARIES[:30])
BANK_SET = set(L.DUAL_BANK)
DIGIT_AMT = set(L.AMOUNTS_DIGIT)
DUAL_ORG_SET = set(L.DUAL_ORG)
ACC_FAMILY = {a: f for a, _, f in L.ACCOUNTS}


def peer_group(label, text):
    if label == "currency":
        return "ccy", CCY_SURFACES[text]
    if label == "method":
        return "rail", METHOD_SURFACES[text]
    if label == "account":
        fam = ACC_FAMILY[text]
        if fam == "named":
            # type-only accounts obligatorily take a determiner and purpose-named
            # ones do not, so they are not interchangeable peers
            fam = "type_only" if text in L.TYPE_ACCOUNTS else "named"
        return "acct:" + fam, text
    if label == "beneficiary":
        kind = "person" if text in PERSONS else ("bank" if text in BANK_SET else "org")
        return "ben:" + kind, text
    if label == "amount":
        return "amt:" + ("digit" if text in DIGIT_AMT else "word"), text
    if label == "template_name":
        return "tmpl:" + ("org" if text in DUAL_ORG_SET else "purpose"), text
    return label, text


prof = defaultdict(lambda: defaultdict(Counter))
totals = defaultdict(Counter)
for r in ROWS:
    for sp in r["spans"]:
        ctx = span_context(r, sp)
        grp, val = peer_group(sp["label"], sp["text"])
        totals[grp][val] += 1
        for d in PROFILE_DIMS:
            prof[grp][val]["%s=%s" % (d, ctx[d])] += 1

say("    %-16s %-5s %-6s %-9s %-9s %s" % ("peer group", "peers", "n/peer", "spread", "noise", "verdict"))
for grp in sorted(prof):
    vals = sorted(prof[grp])
    n_min = min(totals[grp][v] for v in vals)
    keys = set()
    for v in vals:
        keys |= set(prof[grp][v])
    worst, bound_at, worst_key = 0.0, 0.0, ""
    for k in keys:
        share = [prof[grp][v][k] / totals[grp][v] for v in vals]
        spread = max(share) - min(share)
        # spread expected from multinomial sampling alone at this sample size
        pbar = sum(prof[grp][v][k] for v in vals) / sum(totals[grp][v] for v in vals)
        # expected RANGE (max-min) of k binomial proportions, not a 1-sigma
        # band: E[range of k normals] ~ 2*sqrt(2*ln k), plus one granule 1/n
        sigma = (pbar * (1 - pbar) / n_min) ** 0.5
        noise = sigma * 2 * (2 * math.log(max(len(vals), 2))) ** 0.5 + 1.0 / n_min
        if spread - noise > worst - bound_at:
            worst, bound_at, worst_key = spread, noise, k
    ok = worst <= bound_at
    say("    %-16s %-5d %-6d %-9.3f %-9.3f %s%s"
        % (grp, len(vals), n_min, worst, bound_at, "ok" if ok else "FAIL",
           "" if ok else "  at " + worst_key))
    if not ok:
        fail("PROFILE_DIVERGENCE", "%s spread=%.3f noise=%.3f at %s"
             % (grp, worst, bound_at, worst_key))

# ==========================================================================
# 15. LABELLING RATE PER SURFACE  -- the literal form of the reported bug
# ==========================================================================
# "CHAPS was listed under valid methods 16/18 times." A surface that is
# sometimes inside a span and sometimes loose teaches the model that the
# surface is unreliable. Every closed-set surface must be labelled on 100% of
# its occurrences, and every peer must share that rate exactly.
say("\n[15] closed-set token coverage (every occurrence must sit inside a span)")
# The literal form of the reported bug. Note that "EUR" inside "EUR Settlement
# Account" is correctly covered by the ACCOUNT span, and "dollars" inside
# "US dollars" by the CURRENCY span -- what must never happen is a closed-set
# token sitting loose in the text with no span over it at all.
for kind, inventory in (("currency", CCY_SURFACES), ("method", METHOD_SURFACES)):
    loose = Counter()
    total = Counter()
    for r in ROWS:
        cover = [(sp["start"], sp["end"]) for sp in r["spans"]]
        for surf in inventory:
            for m in re.finditer(r"(?<![\w])" + re.escape(surf) + r"(?![\w])", r["input"]):
                total[surf] += 1
                if not any(a <= m.start() and m.end() <= b for a, b in cover):
                    loose[surf] += 1
    rates = {k: 1 - loose[k] / total[k] for k in total}
    say("    %-9s surfaces=%-3d  min coverage=%.3f  loose tokens=%d"
        % (kind, len(rates), min(rates.values()), sum(loose.values())))
    for k, n in loose.most_common(6):
        fail("LOOSE_CLOSED_SET_TOKEN", "%s %r %d/%d uncovered" % (kind, k, n, total[k]))

# ==========================================================================
# 16. SHARED-TRIGGER POSTERIOR  -- P(label | trigger) inside each intent
# ==========================================================================
say("\n[16] P(label | shared trigger '%s') within each intent" % L.SHARED_TRIGGER)
ALL_TRIGGERS = set(L.ACC_PREPS + L.BEN_PREPS + L.MET_PREPS + L.AB_PREPS +
                   L.CCY_TRIGGERS + L.PFT_TRIGGERS)
ONE_WORD_TRIG = {t for t in ALL_TRIGGERS if " " not in t}


def introducing_trigger(r, sp, window=5):
    """Nearest preceding trigger word with no other trigger in between."""
    pre = [w.lower().strip(",-") for w in r["input"][:sp["start"]].strip().split()]
    for w in reversed(pre[-window:]):
        if w in ONE_WORD_TRIG:
            return w
    return None


trig = defaultdict(Counter)
for r in ROWS:
    for sp in r["spans"]:
        if introducing_trigger(r, sp) == L.SHARED_TRIGGER:
            trig[r["intent"]][sp["label"]] += 1
for intent in INTENT_ORDER:
    c = trig[intent]
    allowed = [e for e in INTENT_ENTITIES[intent]]
    hits = {e: c.get(e, 0) for e in allowed if c.get(e, 0) > 0}
    if len(hits) < 2:
        say("    %-20s %s" % (intent, dict(hits) or "trigger unused"))
        continue
    spread = max(hits.values()) - min(hits.values())
    rel = spread / (sum(hits.values()) / len(hits))
    say("    %-20s %-46s spread=%d (%.0f%%)  %s"
        % (intent, dict(sorted(hits.items())), spread, 100 * rel,
           "ok" if rel <= 0.25 else "FAIL"))
    if rel > 0.25:
        fail("TRIGGER_POSTERIOR_SKEWED", "%s %s" % (intent, dict(hits)))

# ==========================================================================
# 17. SURFACE-FORM PROFILE PER CLOSED-SET VALUE
# ==========================================================================
say("\n[17] surface-form profile per value (identical mix required)")
form_of = {}
for code, spec in L.CURRENCIES.items():
    for t in ("code", "word", "sym"):
        for x in spec.get(t, []):
            form_of[x] = t
cmix = defaultdict(Counter)
for r in ROWS:
    for sp in r["spans"]:
        if sp["label"] == "currency":
            cmix[CCY_SURFACES[sp["text"]]][form_of[sp["text"]]] += 1
for code in sorted(cmix):
    tot = sum(cmix[code].values())
    say("    %-5s %s  total=%d" % (code, {k: cmix[code][k] for k in ("code", "word", "sym")}, tot))
# Some patterns forbid a surface class (a symbol needs a digit amount, and a
# couple of frames are word-only), so the per-value class split can land one
# draw either side of the 120/120/60 target. Tolerance is one draw in 300 --
# every VALUE is still at exactly 300 with 0.000 profile divergence, which is
# the property that matters; forcing class exactness would mean distorting
# which patterns each currency is allowed to appear in, a worse trade.
mixes = {tuple(cmix[c][k] for k in ("code", "word", "sym")) for c in cmix}
spread = max(max(m) - min(m) for m in zip(*mixes)) if len(mixes) > 1 else 0
say("    per-value class spread: %d draw(s)" % spread)
if spread > 1:
    fail("CCY_FORM_MIX_NOT_UNIFORM", str(sorted(mixes)))

mpos = defaultdict(Counter)
for r in ROWS:
    for sp in r["spans"]:
        if sp["label"] != "method":
            continue
        canon = METHOD_SURFACES[sp["text"]]
        after = r["input"][sp["end"]:].lstrip().split()
        premod = bool(after) and after[0].lower() in ("payment", "transfer", "rails", "network")
        mpos[canon]["premod" if premod else "prep"] += 1
        mpos[canon]["lower" if sp["text"].islower() else "upper"] += 1
spreads = {}
for k in ("premod", "prep", "lower", "upper"):
    vals = [mpos[c][k] for c in mpos]
    spreads[k] = max(vals) - min(vals)
say("    method position/case spread across the 13 rails: %s" % spreads)


# ===================================================================== verdict
say("\n" + "=" * 78)
if FAIL:
    say("FAILURES: %d" % len(FAIL))
    shown = Counter(f.split()[0] for f in FAIL)
    for k, v in shown.most_common():
        say("  %-36s %d" % (k, v))
    for f in FAIL[:25]:
        say("   " + f)
else:
    say("ALL CHECKS PASSED - 0 failures")
if WARN:
    say("warnings: %d" % len(WARN))
    for w in WARN[:15]:
        say("   " + w)
say("=" * 78)

report = "\n".join(OUT)
print(report)
open("validation_report.txt", "w", encoding="utf-8").write(report + "\n")
