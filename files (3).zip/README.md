# Banking intent + entity corpus for GLiNER2 fine-tuning

4,000 examples · 4 intents × 1,000 · `generate.py` builds it, `validate.py`
proves it, `balance.py` is the allocator that makes it safe. Seed `20260804`.

**Audit status: ALL CHECKS PASSED — 0 failures across 17 sections.**

### Post-build adversarial pass

A second review looked for leakage the main auditor was not written to catch,
since it shares the generator's blind spots. Four real defects were found and
fixed:

| defect | before | after |
|---|---|---|
| **Standalone frames were intent-specific** — 200 examples per intent (20% of the corpus) whose opening words were a perfect giveaway, including semantically *neutral* ones (`Before I proceed,` `For my records,`). Replaced with one shared 10-frame pool used identically by all four intents | 18 first-token surfaces at >90% purity | **0** |
| **Time vocabulary shared in wordlist but not in position** — `week`/`month`/`back` were 96% PAY_FROM_TEMPLATE because only that intent ever placed them sentence-finally. `repeat the payment from last week` would have been mispredicted. REPEAT_PAYMENT patterns now put the phrase last too, and both intents draw from one `SHARED_TIME` pool | 16 last-token leaks | **6**, all semantically earned |
| **Account prepositions were fully disjoint** between NEW_PAYMENT and ACCOUNT_BALANCE — `from` before an account was 100% NEW_PAYMENT, so `get the balance from my savings account` had no support. `from` now serves both | 100% split | shared |
| **Present-time tails were ACCOUNT_BALANCE-only**, making `now`/`morning` a perfect cue. The same pool now closes payment sentences | 100% AB | shared |

Verified clean: **0** repeated words, **0** double prepositions, **0** dangling
function words, **0** malformed punctuation, **0** non-ASCII beyond the three
currency symbols, **0** slang or non-English tokens, 623 distinct word forms.

**Phrasing diversity** — after masking entity values, distinct sentence
skeletons per intent:

```
NEW_PAYMENT        999/1000     PAY_FROM_TEMPLATE  1000/1000
REPEAT_PAYMENT    1000/1000     ACCOUNT_BALANCE     999/1000
```

Essentially every sentence has a unique structure; the most-repeated skeleton
appears twice.

**What remains, stated honestly.** Six sentence-final tokens are still
>90% one intent, and all six are earned by meaning rather than by artifact:
`transfer`/`payment` (rails exist only in NEW_PAYMENT), `template`
(PAY_FROM_TEMPLATE), `position`/`is` (balance phrasing), `more` (*once more*).
Six function-word bigrams likewise: `out of` (you debit *out of* an account),
`in the`/`in my`/`in our` (you read a balance *in* one), `that is`, `out the`.
Removing these would mean writing unnatural English. Also: per-currency surface
class can sit one draw either side of 120/120/60, because some frames forbid a
symbol or a code — every currency VALUE is still at exactly 300 with 0.000
profile divergence, which is the property that matters.

---

## 1. The design rule, and why it is not "equal counts"

GLiNER2 is a bidirectional encoder that serialises your label text into the
same input as the sentence and scores span representations against label
representations. It is doing *representation matching*, not membership testing
against your `method` enum — so closed-set membership has to be learned from
examples, and every unlabelled token is an active negative.

You described the real failure precisely: a rail that was labelled 16/18 times
instead of 18/18 poisoned that one value while its peers were fine. The lesson
generalises past counting. **A skew is learnable if and only if it appears in
some marginal of the joint distribution.** The full joint is impossible to
balance (5 currencies × 3 forms × 32 subsets × 10 patterns ≫ 1000 rows), but
every *two-way* margin is achievable and sufficient:

> for every entity value, its distribution over intent, pattern, entity subset,
> frame, introducing trigger, surface form and co-occurring entities must be
> indistinguishable from every peer value's.

`balance.py` enforces this with a greedy min-max allocator; `validate.py`
re-derives it from the raw text and never trusts the generator.

### The measured result

Per-peer-group profile divergence — the largest L∞ distance between any two
peer values across all six context dimensions:

```
acct:bank_name  acct:bank_plus_type  acct:ccy_named  acct:masked      0.000
acct:named      acct:type_only       amt:digit       amt:word         0.000
ben:bank        ben:org              ben:person                       0.000
ccy (5 values, n=300 each)           rail (13 values, n=38 each)      0.000
tmpl:org        tmpl:purpose                                          0.000
```

Zero, not "within tolerance". No value differs from its peers in any tracked
context. Peer groups are linguistically interchangeable sets — `HDFC Bank` is
never preceded by *the* and `the current account` always is, which is grammar,
not skew, so accounts are compared inside their family.

### Closed-set token coverage

```
currency   13 surfaces   min coverage 1.000   loose tokens 0
method     22 surfaces   min coverage 1.000   loose tokens 0
```

Your 16/18 case is impossible here by construction: no currency or method token
appears anywhere in 4,000 sentences without a span covering it. (`EUR` inside
`EUR Settlement Account` is covered by the ACCOUNT span — correct per your
definitions; what never happens is a rail sitting loose.)

---

## 2. Balance guarantees

```
intents               1000 each
entity marginals      EXACTLY 500/1000 in every intent that allows the slot
subsets               NEW_PAYMENT 32 subsets @ 31-32; others 125 / 500 exactly
pairwise              max deviation from n/4: 1.0 (NP), 0.0 (PFT, RP)
currency values       100 per value PER INTENT, in all three intents
currency form mix     120 code / 120 word / 60 symbol -- IDENTICAL for all five
method values         38-39 each (13 does not divide 500; see §5)
method position/case  spread across the 13 rails: premod 7, prep 7, case 30
accounts              100 surfaces x 5 per intent; 5 families x 100 uses each
beneficiaries         125 x 4      templates 100 x 5      amounts 100 x 5
cross-intent parity   0 surfaces with unequal counts, for every open set
duplicates            0
pattern x entity      0 cells with <5 examples on either side
```

Every open set is sized to divide its budget exactly. That is not cosmetic: at
112 beneficiaries, 500/112 = 4.46 meant 52 names appeared 5 times and 60
appeared 4 — a 25% per-value skew invisible in the totals, and the same class of
defect as your 16/18.

---

## 3. Your three failure modes

| # | Symptom | Countermeasure | Count |
|---|---|---|---|
| 1 | `CHAPS` predicted as `currency` | `currency` and `method` made statistically independent in NEW_PAYMENT: 250 both / 251 currency-only / 251 method-only / 250 neither. Both appear after `via/through/using/by/in` and as pre-modifiers | 1000 |
| 2 | `fresh payment`, `transfer` extracted as `method` | 1,398 unlabelled `payment`, 301 bare `transfer`, plus `funds/money/fresh/one-off/dues/amount/instruction`. Minimal pairs: `a transfer of 500 USD` (no method) vs `a bank transfer of 500 USD`. 133 cases of `NEFT transfer` where gold is **`NEFT` only** | 1,842 negatives |
| 3 | `from HDFC Bank` missed | Accounts balanced by **form family**: bare bank names get 200 mentions, exactly equal to every other family | 200 |

Plus: **200** sentences with a denomination inside an account name labelled
`account` not `currency` (50 of them alongside a different real currency);
**400** sentences containing the word *account* with no `account` entity;
**500** template sentences with no `template_name`; **781** zero-entity
examples.

### The shared trigger

`use / using` was resolving to method 127× but currency 29× — a lopsided
posterior is a shortcut. Extraction is intent-conditioned, so the requirement
is flatness *within* each intent:

```
NEW_PAYMENT        account 60   currency 76   method 60      spread 24%
PAY_FROM_TEMPLATE  currency 82  template_name 80             spread  2%
```

---

## 4. Role ambiguity — a deliberate design decision

The first build kept accounts, beneficiaries and templates 100% string-disjoint.
That is a memorisation shortcut: the encoder learns *Acme Industries ⇒
beneficiary* and never learns to read the role off the syntax. In production
every new payee is an unseen string, so this fails exactly where it matters.

So: all 20 bank names serve as both `account` and `beneficiary`
(`pay HDFC Bank` vs `from HDFC Bank`), and 20 organisations as both
`beneficiary` and `template_name`. Every member of each pool has an *identical*
role profile, machine-checked; and no string may fill two roles in one sentence
(substring collisions included). If you would rather have disjoint inventories,
delete `DUAL_BANK` / `DUAL_ORG` in `lexicon.py` and regenerate.

---

## 5. The one irreducible residue, stated plainly

13 rails do not divide 500, so six get 39 and seven get 38. This cannot be
removed without changing either your closed set or the exact-50% marginal. It is
**not** the failure you described: that was a *conditional* defect (a value
sometimes unlabelled), whereas this is a ±1 count with, as section [14] shows,
**0.000** profile divergence — every rail has an identical distribution over
position, case, trigger, pattern, subset and co-entities. If you want it exactly
uniform, set the NEW_PAYMENT method marginal to 507 (13 × 39) and adjust
`BONUS_NP`; you trade a 0.7% marginal deviation for a 2.6% per-value one, which
is the worse bargain.

---

## 6. Training wiring

* **Two-stage inference**: classify intent, then extract with *only* that
  intent's label list. `raw_spans.jsonl` carries a per-row `schema` field.
* **Negative labels**: rails are physically absent from the three non-payment
  intents, so you can safely add `method` to their schema with an empty gold
  list for a fraction of steps — a true negative that teaches abstention. Do
  **not** do this for `currency` in ACCOUNT_BALANCE: denomination tokens do
  occur there, inside account names.
* **Shuffle label order** in the serialised schema between epochs; encoders pick
  up positional bias in the prompt.
* **Normalise after extraction.** Gold spans are the surface string (`neft`,
  `£`, `dollars`). Map surface → canonical in post-processing; forcing a form
  the model cannot see in the text causes span drift.
* **Split by skeleton, not randomly.** Hold out 2 patterns per intent and 10% of
  each open-set lexicon. A random split reports inflated numbers because the
  same skeleton appears on both sides.
* **LoRA r=16–32** on the attention projections. Higher ranks memorise skeletons.

---

## 7. Extending it

The corpus is a pure function of the lexicon plus the intent registry. Balance
is a whole-corpus property, so **always regenerate and retrain from base** —
never append to `raw.jsonl`. That is why the generator, not the JSONL, is the
real deliverable.

**New entity on an existing intent** — add the inventory to `lexicon.py` (sized
to divide 500; the import-time assertions will reject a ragged or duplicated
list), add the label to `INTENT_ENTITIES`, add a chunk to that intent's pattern
functions rendering correctly both with and without the slot, then
`python generate.py && python validate.py`.

**New intent** — add to `INTENT_ENTITIES`, write `build_<intent>()` with 8–10
patterns and 5 standalone frames reusing `money_juxt` / `attach` / `WRAPPERS`,
register in `BUILDERS` and `INTENT_ORDER`, extend `make_quotas`. `validate.py`
needs no changes: it derives its expectations from `INTENT_ENTITIES` and the
lexicon.

**Two rules when you add anything.** Every new value choice must declare the
margins it has to stay uniform inside (the `dims` argument), and any lexical
choice that will sit *next to* a span must be conditioned on that span's value.
Unconditioned neighbours were the single largest source of skew in this build —
prepositions balanced globally but not against the value they introduce.

**The auditor will catch**: loose closed-set tokens, rails leaking into intents
without a `method` slot, profile divergence beyond sampling noise, skewed
trigger posteriors, non-uniform surface-form mixes, undeclared ambiguous
strings, dual pools with unequal role profiles, ragged or duplicated
inventories, ambiguous/overlapping spans, determiners inside account spans,
unequal cross-intent counts, missing subsets, duplicates, thin cells.

---

## 8. Files

| file | purpose |
|---|---|
| `raw.jsonl` | 4,000 rows, `{"input", "intent", "entities"}` — your requested format |
| `raw_spans.jsonl` | same rows + char offsets, per-row `schema`, pattern/subset metadata |
| `balance.py` | the multi-margin allocator; read this first to understand the design |
| `generate.py` | patterns, subset planning, margin declarations |
| `lexicon.py` | every surface inventory + integrity assertions |
| `validate.py` | independent auditor; recomputes everything from the text |
| `validation_report.txt` | the full 17-section audit for this build |
