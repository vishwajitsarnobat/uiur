# -*- coding: utf-8 -*-
"""
balance.py -- the allocator that makes the corpus safe for a span-scoring
encoder such as GLiNER2.

WHY THIS EXISTS
---------------
A plain per-value quota ("CHAPS 38 times, SEPA 38 times") is not enough. The
failure mode that actually breaks these models is a *conditional* skew: a value
that is treated slightly differently from its peers in some context. The
classic case is a rail that is labelled 16/18 times instead of 18/18 because two
of its sentences happened to land in an intent with no `method` slot. Totals
look fine; the conditional distribution does not; the encoder learns that this
one value is unreliable and starts assigning it to a neighbouring label.

Formally: a skew is only learnable if it is visible in some marginal of the
joint distribution. Enforcing the FULL joint is combinatorially impossible
(5 currencies x 3 forms x 32 subsets x 10 patterns >> 1000 rows). Enforcing
every TWO-WAY margin is both achievable and sufficient for the failure modes
that matter, because a model that sees value v with an identical profile over
intent, pattern, subset, surface form, syntactic position, introducing trigger
and co-occurring entities has no signal that distinguishes v from its peers
other than the label we assign it.

HOW
---
`Balanced` keeps one contingency table per declared dimension. On each draw it
picks the value minimising, lexicographically:

    1. the worst (maximum) count it currently holds across every active margin
       cell -- this is the min-max step that flattens all 2-way margins
    2. its global fill ratio -- this preserves the exact per-value totals
    3. a seeded random key -- deterministic tie-break, no ordering bias

Greedy min-max keeps every tracked cell within +/-1 of uniform whenever the
allowed-set constraints permit it, which the validator then re-derives from the
generated text and asserts independently.
"""
import random


def even_counts(items, total):
    """Deterministic near-uniform allocation. Deterministic on purpose: every
    intent then receives an IDENTICAL per-value budget, so cross-intent parity
    is exact rather than merely approximate."""
    items = list(items)
    base, rem = divmod(total, len(items))
    return {it: base + (1 if i < rem else 0) for i, it in enumerate(items)}


class Balanced:
    """Exact-total sampler that additionally flattens every declared margin.

    jitter  : drop the margin term for one draw. Used only when the sentence
              space around a cell is exhausted and the generator would
              otherwise emit a duplicate; totals stay exact either way.

    items   : the value universe
    total   : how many draws this balancer must serve
    dims    : names of context dimensions to keep uniform against, e.g.
              ("intent", "pattern", "subset", "form", "position", "trigger")
    counts  : explicit per-value budget, overriding the even split
    """

    __slots__ = ("budget", "used", "dims", "cells", "rng", "name")

    def __init__(self, items, total, rng, dims=(), counts=None, name=""):
        self.budget = dict(counts) if counts is not None else even_counts(items, total)
        self.used = {k: 0 for k in self.budget}
        self.dims = tuple(dims)
        self.cells = {}
        self.rng = rng
        self.name = name

    def _cell(self, key):
        c = self.cells.get(key)
        if c is None:
            c = self.cells[key] = {}
        return c

    def pick(self, ctx=None, allowed=None, jitter=False):
        keys = list(self.budget) if allowed is None else [k for k in allowed if k in self.budget]
        if not keys:
            raise ValueError("no candidate for balancer %r (allowed=%r)" % (self.name, allowed))
        # respect the hard budget, but never dead-end: fall back to the allowed
        # set once every candidate is exhausted
        cands = [k for k in keys if self.used[k] < self.budget[k]] or keys

        active = []
        if ctx:
            for d in self.dims:
                v = ctx.get(d)
                if v is not None:
                    active.append((d, v))

        # Score each candidate by how far ABOVE its cell's current minimum it
        # sits, not by its raw count. Raw counts are not comparable across
        # dimensions: a cell holding 400 draws always dominates a cell holding
        # 31, so `max(raw)` silently ignores the small cell and lets it skew.
        # Measuring excess-over-minimum makes every margin equally weighted.
        floors = []
        for cell_key in active:
            c = self._cell(cell_key)
            floors.append((c, min(c.get(k, 0) for k in cands)))

        best_key, best_score = None, None
        for k in cands:
            worst = 0
            for c, mn in floors:
                excess = c.get(k, 0) - mn
                if excess > worst:
                    worst = excess
            b = self.budget[k]
            score = (0 if jitter else worst,
                     self.used[k] / b if b else float("inf"),
                     self.rng.random())
            if best_score is None or score < best_score:
                best_key, best_score = k, score

        self.used[best_key] += 1
        for cell_key in active:
            c = self._cell(cell_key)
            c[best_key] = c.get(best_key, 0) + 1
        return best_key, active

    def refund(self, value, active):
        """Undo a draw completely -- global count and every margin cell."""
        self.used[value] -= 1
        for cell_key in active:
            c = self._cell(cell_key)
            c[value] -= 1


def margin_report(counts_by_cell, label=""):
    """Max absolute deviation of any value from the cell mean. Used by the
    validator to turn 'is it balanced?' into a single number."""
    worst = 0.0
    for cell, counter in counts_by_cell.items():
        if not counter:
            continue
        mean = sum(counter.values()) / len(counter)
        for v in counter.values():
            worst = max(worst, abs(v - mean))
    return worst
