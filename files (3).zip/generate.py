# -*- coding: utf-8 -*-
"""
generate.py -- builds a fully balanced GLiNER2 fine-tuning corpus.

Balance guarantees (all re-checked independently by validate.py):
  * every entity type is present in EXACTLY 50% of the examples of every intent
    that allows it -> the model gets zero prior on "is this slot filled?"
  * every entity SUBSET of an intent is equally represented -> zero mutual
    information between any two entity slots
  * every closed-set VALUE (5 currencies, 13 methods) gets an identical number
    of occurrences in every intent that allows it
  * every open-set surface (100 accounts, 100 beneficiaries, 50 templates,
    60 amount forms) is drawn from an exact quota, identical across intents
  * the 20 register wrappers are shared verbatim by all four intents (40 uses
    each); the other 200 per intent use 5 idiomatic standalone frames
"""
import json
import random
import itertools

import lexicon as L
from balance import Balanced, even_counts, margin_report

SEED = 20260804
N_PER_INTENT = 1000
N_WRAPPED = 800
N_STANDALONE = 200

INTENT_ENTITIES = {
    "NEW_PAYMENT": ["account", "amount", "currency", "beneficiary", "method"],
    "PAY_FROM_TEMPLATE": ["amount", "currency", "template_name"],
    "REPEAT_PAYMENT": ["beneficiary", "amount", "currency"],
    "ACCOUNT_BALANCE": ["account"],
}
INTENT_ORDER = ["NEW_PAYMENT", "PAY_FROM_TEMPLATE", "REPEAT_PAYMENT", "ACCOUNT_BALANCE"]


# ---------------------------------------------------------------- fragments
def T(text):
    return (text, None, " ")


def E(text, label):
    return (text, label, " ")


def EG(text, label):                     # glued, no preceding space -> "$500"
    return (text, label, "")


def render(frags):
    s, spans = "", []
    for txt, label, pre in frags:
        if not txt:
            continue
        if s and pre:
            s += pre
        start = len(s)
        s += txt
        if label:
            spans.append({"label": label, "text": txt, "start": start, "end": len(s)})
    return s, spans


def shift(spans, k):
    return [{**sp, "start": sp["start"] + k, "end": sp["end"] + k} for sp in spans]


# ------------------------------------------------------------------- quotas
# Every draw below is made through balance.Balanced, which keeps the value
# uniform inside EVERY declared margin cell (intent, pattern, entity subset,
# surface form, syntactic position, introducing trigger) rather than merely
# hitting a global total. See balance.py for why the totals alone are not safe.

CTX_DIMS = ("intent", "subset", "pattern", "frame", "position", "trigger",
            "co_labels",
            "canon", "ctype", "has_amount", "has_ccy", "role",
            "acc", "ben", "amt", "ccy", "tmpl")


class Picker:
    """Transactional facade. Carries the ambient context so that every value
    drawn for a sentence is balanced against that sentence's intent, pattern
    and entity subset; a rejected sentence returns every filler it consumed,
    margin cells included."""

    def __init__(self, quotas, rng):
        self.q = quotas
        self.rng = rng
        self.log = []
        self.person = "you"
        self.ctx = {}
        self.jitter = False

    def begin(self, person, **ctx):
        self.log = []
        self.person = person
        self.ctx = ctx

    def setctx(self, **kw):
        self.ctx.update(kw)

    def pick(self, name, allowed=None, **extra):
        ctx = dict(self.ctx, **extra) if extra else self.ctx
        v, active = self.q[name].pick(ctx, allowed, jitter=self.jitter)
        self.log.append((name, v, active))
        return v

    def det(self, mode):
        return self.rng.choice(L.ACCOUNT_DETS[mode])

    def pick_account(self, **extra):
        fam = self.pick("acc_family", **extra)
        text, det_mode = self.pick("acc_surf_" + fam, **extra)
        return text, det_mode

    def pick_currency(self, allowed_codes, types, **extra):
        """One joint draw over (value, surface-class). Drawing the code and
        then its form separately is what let GBP/INR/USD drift to 2:1 word
        forms while EUR/SGD stayed even: currencies with more word aliases
        soaked up more of the word budget. Balancing the pair fixes the
        per-value form profile by construction."""
        # Stage 1 draws the VALUE, stage 2 its surface class from a per-value
        # budget. Drawing the (value, class) pair jointly kept the form mix even
        # but let the value margin drift inside a cell, because a cell could be
        # served by one code's symbol and another code's word form. Splitting
        # the stages makes both margins exact: the code is balanced against
        # every context dim, and the 40/40/20 class mix is fixed per code.
        ok = [c for c in allowed_codes if any(L.CURRENCIES[c].get(t) for t in types)]
        code = self.pick("ccy_code", ok, **extra)
        avail = [t for t in types if L.CURRENCIES[code].get(t)]
        extra.pop("amt", None)
        self.ctx = dict(self.ctx, ccy=code)
        ctype = self.pick("ccy_class_" + code, avail, ccy=code, **extra)
        surf = self.pick("ccy_surf_%s_%s" % (code, ctype), ctype=ctype, ccy=code, **extra)
        return code, surf, ctype

    def method_form(self, canon, position, **extra):
        idx = self.pick("met_form_" + canon, position=position, canon=canon, **extra)
        return L.METHODS[canon]["forms"][idx]

    def note(self, key, value, active=()):
        self.log.append((key, value, active))

    def rollback(self, extra):
        for name, v, active in reversed(self.log):
            (extra if name in extra else self.q)[name].refund(v, active)
        self.log = []


# ------------------------------------------------------------- entity subsets
BONUS_NP = [
    ("account", "amount"), ("currency", "beneficiary"), ("method", "account"),
    ("amount", "currency"), ("account", "beneficiary", "method"),
    ("amount", "beneficiary", "method"), ("currency", "beneficiary", "method"),
    ("account", "amount", "currency"),
]


def subset_plan(intent, rng):
    ents = INTENT_ENTITIES[intent]
    subsets = [frozenset(c) for r in range(len(ents) + 1)
               for c in itertools.combinations(ents, r)]
    base, rem = divmod(N_PER_INTENT, len(subsets))
    counts = {s: base for s in subsets}
    if rem:
        # 32 subsets do not divide 1000; the 8 top-up subsets are chosen so that
        # each of the five slots gains exactly +4 -> marginals stay at exactly 500
        assert intent == "NEW_PAYMENT" and rem == 8
        for b in BONUS_NP:
            counts[frozenset(b)] += 1
    plan = []
    for s, c in counts.items():
        plan += [s] * c
    assert len(plan) == N_PER_INTENT
    rng.shuffle(plan)
    return plan


# -------------------------------------------------------------- money helpers
def money_juxt(p, amt, surf, ctype, code=None):
    """'500 USD' / 'USD 500' / '$500' / '500' / 'in USD'"""
    if amt and surf:
        if ctype == "sym":
            return [E(surf, "currency"), EG(amt, "amount")], "quantity"
        if ctype == "code" and p.pick("ccy_order") == "CA":
            return [E(surf, "currency"), E(amt, "amount")], "quantity"
        return [E(amt, "amount"), E(surf, "currency")], "quantity"
    if amt:
        return [E(amt, "amount")], "quantity"
    if surf:
        return [T(p.pick("ccy_trigger", trigger="ccy", ccy=code)), E(surf, "currency")], "in_phrase"
    return [], None


def money_sep(p, amt, surf, code=None):
    """quantity and denomination pulled apart: 'an amount of 500 in USD'"""
    if amt and surf:
        return [T("an amount of"), E(amt, "amount"), T("in"), E(surf, "currency")], "quantity"
    if amt:
        return [T("an amount of"), E(amt, "amount")], "quantity"
    if surf:
        return [T(p.pick("ccy_trigger", trigger="ccy", ccy=code)), E(surf, "currency")], "in_phrase"
    return [], None


def attach(prep, money, kind, banned=()):
    """Hang a money chunk off a preposition; drop the preposition when the
    chunk is already a PP, and swap it when it would duplicate a nearby one."""
    if not money:
        return []
    if kind == "in_phrase":
        return money
    if prep in banned:
        prep = "of" if prep != "of" else "for"
    return [T(prep)] + money


# =============================================================== NEW_PAYMENT
def build_new_payment(p, subset, pattern):
    has = subset.__contains__
    acc_frags, acc_txt, acc_prep = [], None, None
    ben_frags, ben_prep = [], None
    met_frags = []

    if has("account"):
        acc_txt, det_mode = p.pick_account()
        det = p.det(det_mode)
        acc_prep = p.pick("acc_prep", acc=acc_txt)
        acc_frags = [T(acc_prep)] + ([T(det)] if det else []) + [E(acc_txt, "account")]
    elif p.pick("acc_bare_mode") == "bare":
        # non-identifying account wording -> deliberately NOT an entity
        bare = p.pick("bare_account")
        acc_prep = p.pick("acc_prep_bare", acc=bare)
        acc_frags = [T(acc_prep), T(bare)]
    if has("beneficiary"):
        # DUAL_BANK strings can fill either slot; forbid the same string twice
        # substring, not equality: "State Bank of India" as payee alongside
        # "State Bank of India savings account" leaves the span unresolvable
        pool = [b for b in L.BENEFICIARIES
                if b not in acc_txt and acc_txt not in b] if acc_txt else None
        ben = p.pick("beneficiary", pool, role="payee")
        ben_prep = p.pick("ben_prep", ben=ben)
        ben_frags = [T(ben_prep), E(ben, "beneficiary")]

    amt = p.pick("amount") if has("amount") else None
    if has("currency"):
        blocked = L.ACCOUNT_EMBEDDED_CCY.get(acc_txt)      # 'USD Trade Account'
        codes = [c for c in L.CCY_CODES if c != blocked]
        if pattern == 5:
            types = ["code"]                                # 'a USD payment'
        elif pattern == 10:
            types = ["code", "word"]                        # '... in dollars'
        elif amt in L.AMOUNTS_DIGIT:
            types = ["code", "word", "sym"]
        else:
            types = ["code", "word"]
        ccy, surf, ctype = p.pick_currency(codes, types, amt=amt)
    else:
        ccy = surf = ctype = None

    if has("method") and pattern != 4:
        canon = p.pick("method", position="prep")
        form = p.method_form(canon, "prep")
        mprep = p.pick("met_prep", [x for x in L.MET_PREPS if x != acc_prep] or None,
                       canon=canon, position="prep")
        met_frags = [T(mprep), E(form[0], "method")] + [T(w) for w in form[1:]]

    ban = {ben_prep}
    if pattern in (1, 6, 9):
        money, kind = money_juxt(p, amt, surf, ctype, ccy)
        vp = [T(p.pick("np_vp_nominal"))]
        if pattern == 1:
            frags = vp + attach("of", money, kind) + ben_frags + acc_frags + met_frags
        elif pattern == 9:
            frags = vp + attach("of", money, kind) + acc_frags + ben_frags + met_frags
        else:
            frags = vp + ben_frags + attach("for", money, kind, ban) + acc_frags + met_frags

    elif pattern in (2, 3, 7):
        money, kind = money_juxt(p, amt, surf, ctype, ccy)
        verb = p.pick("np_vp_trans")
        if kind == "quantity":
            obj = money
        elif kind == "in_phrase":
            obj = [T(p.pick("np_defobj_" + verb))] + money
        else:
            obj = [T(p.pick("np_defobj_" + verb))]
        head = [T(verb)] + obj
        if pattern == 2:
            frags = head + ben_frags + acc_frags + met_frags
        elif pattern == 3:
            frags = head + acc_frags + ben_frags + met_frags
        else:
            frags = head + met_frags + ben_frags + acc_frags

    elif pattern == 4:                                     # rail as pre-modifier
        money, kind = money_juxt(p, amt, surf, ctype, ccy)
        vp = [T(p.pick("np_vp_bare"))]
        if has("method"):
            canon = p.pick("method", position="premod")
            spec = L.METHODS[canon]
            surface = p.method_form(canon, "premod")[0]
            core = [T(spec["art"]), E(surface, "method")]
            if spec["head"]:
                core.append(T(spec["head"]))
        else:
            core = [T("a"), T(p.pick("np_generic_head"))]
        frags = vp + core + attach("of", money, kind) + ben_frags + acc_frags

    elif pattern == 5:                                     # denomination as pre-modifier
        vp = [T(p.pick("np_vp_bare"))]
        if surf:
            core = [T(L.CURRENCIES[ccy]["art"]), E(surf, "currency"), T("payment")]
        else:
            core = [T("a"), T(p.pick("np_generic_head"))]
        money = [T("of"), E(amt, "amount")] if amt else []
        frags = vp + core + money + ben_frags + acc_frags + met_frags

    elif pattern == 8:                                     # ditransitive
        money, kind = money_juxt(p, amt, surf, ctype, ccy)
        if ben_frags:
            head = [T("pay"), ben_frags[1]] + money
        elif kind == "quantity":
            head = [T("pay")] + money
        elif kind == "in_phrase":
            head = [T("pay"), T("the dues")] + money
        else:
            head = [T("pay"), T(p.pick("np_pay_obj"))]
        frags = head + acc_frags + met_frags

    elif pattern == 10:                                    # quantity / denomination split
        money, kind = money_sep(p, amt, surf, ccy)
        verb = p.pick("np_vp_trans")
        if kind == "quantity":
            head = [T(verb)] + money
        elif kind == "in_phrase":
            head = [T(verb), T(p.pick("np_defobj_" + verb))] + money
        else:
            head = [T(verb), T(p.pick("np_defobj_" + verb))]
        frags = head + ben_frags + acc_frags + met_frags
    else:
        raise ValueError(pattern)
    tail_now = p.pick("now_suffix")
    if tail_now:
        frags = frags + [T(tail_now)]
    return frags


NP_STANDALONE = [
    "Payment request - {C}.",
    "New payment: {C}.",
    "There is a payment to be made - {C}.",
    "Raise this today: {C}.",
    "Action needed - {C}.",
]


# ========================================================= PAY_FROM_TEMPLATE
def tmpl_chunk(p, subset):
    if "template_name" in subset:
        name = p.pick("template")
        pre, post = p.pick("pft_ref_named", tmpl=name).split("{T}")
        frags = ([T(pre.strip())] if pre.strip() else []) + [E(name, "template_name")]
        if post.strip():
            frags.append(T(post.strip()))
    else:
        frags = [T(p.pick("pft_ref_anon"))]
    suf = p.pick("pft_time")
    if suf:
        frags.append(T(suf))
    return frags


def build_pay_from_template(p, subset, pattern):
    has = subset.__contains__
    amt = p.pick("amount") if has("amount") else None
    if has("currency"):
        types = ["code", "word", "sym"] if amt in L.AMOUNTS_DIGIT else ["code", "word"]
        ccy, surf, ctype = p.pick_currency(L.CCY_CODES, types, amt=amt)
    else:
        ccy = surf = ctype = None
    money, kind = money_juxt(p, amt, surf, ctype, ccy)
    tmpl = tmpl_chunk(p, subset)

    if pattern == 1:
        frags = [T(p.pick("pft_vp_use"))] + tmpl + attach("for", money, kind)
    elif pattern == 2:
        frags = [T(p.pick("pft_vp_make"))] + attach("of", money, kind) + [T(p.pick("pft_trigger", trigger="tmpl"))] + tmpl
    elif pattern == 3:
        tail = [T("and"), T(p.pick("pft_vp_pay"))]
        if kind == "quantity":
            tail += money
        elif kind == "in_phrase":
            tail += [T("it")] + money
        else:
            tail += [T("it")]
        frags = [T(p.pick("pft_vp_use"))] + tmpl + tail
    elif pattern == 4:
        frags = [T(p.pick("pft_vp_run"))] + tmpl + attach("for", money, kind)
    elif pattern == 5:
        frags = [T(p.pick("pft_vp_make"))] + attach("of", money, kind) + [T(p.pick("pft_trigger", trigger="tmpl"))] + tmpl
    elif pattern == 6:
        verb = p.pick("pft_vp_pay")
        if kind == "quantity":
            obj = money
        elif kind == "in_phrase":
            obj = [T("the amount")] + money
        else:
            obj = [T("the amount")]
        frags = [T(verb)] + obj + [T(p.pick("pft_trigger", trigger="tmpl"))] + tmpl
    elif pattern == 7:
        frags = [T(p.pick("pft_vp_use"))] + tmpl + [T("and process it")] + attach("for", money, kind)
    elif pattern == 8:
        frags = [T(p.pick("pft_vp_make"))] + attach("of", money, kind) + [T(p.pick("pft_trigger", trigger="tmpl"))] + tmpl
    else:
        raise ValueError(pattern)
    return frags


PFT_STANDALONE = [
    "The saved setup should be used - {C}.",
    "Template payment: {C}.",
    "For the recurring instruction, {C}.",
    "As per the stored setup - {C}.",
    "Standing instruction: {C}.",
]


# ============================================================ REPEAT_PAYMENT
def build_repeat_payment(p, subset, pattern):
    has = subset.__contains__
    amt = p.pick("amount") if has("amount") else None
    if has("currency"):
        types = ["code", "word", "sym"] if amt in L.AMOUNTS_DIGIT else ["code", "word"]
        ccy, surf, ctype = p.pick_currency(L.CCY_CODES, types, amt=amt)
    else:
        ccy = surf = ctype = None
    money, kind = money_juxt(p, amt, surf, ctype, ccy)

    ben_frags, ben_prep = [], None
    if has("beneficiary"):
        # DUAL_BANK strings can fill either slot; forbid the same string twice
        ben = p.pick("beneficiary", role="payee")
        ben_prep = p.pick("ben_prep", ben=ben)
        ben_frags = [T(ben_prep), E(ben, "beneficiary")]
    ban = {ben_prep}

    noun = p.pick("rp_noun")
    adj = p.pick("rp_adj")
    tpp = p.pick("rp_time_pp")

    if pattern == 1:
        frags = [T(p.pick("rp_vp_repeat")), T(adj), T(noun)] + \
                attach("of", money, kind) + ben_frags
    elif pattern == 2:
        ref = p.pick("rp_clause") if p.rng.random() < 0.5 else tpp
        frags = [T(p.pick("rp_vp_repeat")), T("the " + noun)] + ben_frags + \
                attach("for", money, kind, ban) + [T(ref)]
    elif pattern == 3:
        frags = [T(p.pick("rp_vp_do")), T("the same " + noun), T("again")] + \
                attach("of", money, kind) + ben_frags
    elif pattern == 4:
        frags = [T(p.pick("rp_vp_repeat")), T(adj), T(noun)] + attach("of", money, kind) + ben_frags
    elif pattern == 5:
        frags = [T(p.pick("rp_vp_repeat")), T("the " + noun)] + ben_frags + [T(tpp), T("once more")] + \
                attach("for", money, kind, ban)
    elif pattern == 6:
        frags = [T(p.pick("rp_vp_do")), T("the same " + noun), T(p.pick("rp_asref"))] + ben_frags + \
                attach("of", money, kind, ban)
    elif pattern == 7:
        frags = [T("take " + adj + " " + noun)] + ben_frags + [T("and"), T(p.pick("rp_vp_repeat")), T("it")] + \
                attach("for", money, kind, ban)
    elif pattern == 8:
        frags = [T(p.pick("rp_vp_repeat")), T("what was sent")] + ben_frags + \
                attach("for", money, kind, ban) + [T(tpp)]
    else:
        raise ValueError(pattern)
    tail_now = p.pick("now_suffix")
    if tail_now:
        frags = frags + [T(tail_now)]
    return frags


RP_STANDALONE = [
    "Same as before - {C}.",
    "Repeat request: {C}.",
    "Like the earlier one, {C}.",
    "One more time - {C}.",
    "Again please: {C}.",
]


# =========================================================== ACCOUNT_BALANCE
def build_account_balance(p, subset, pattern):
    has_acc = "account" in subset
    allow_me = p.person == "you"
    verb = p.pick("ab_verb", L.AB_VERBS if allow_me else L.AB_VERBS_NEUTRAL)
    measure = p.pick("ab_measure")
    bal = p.pick("ab_bal_noun")

    loc_only = pattern in (3, 6, 8)
    tail = []
    if has_acc:
        acc, det_mode = p.pick_account()
        det = p.det(det_mode)
        prep = "in" if loc_only else p.pick("ab_prep", acc=acc)
        tail = [T(prep)] + ([T(det)] if det else []) + [E(acc, "account")]
    elif p.pick("acc_bare_mode") == "bare":
        bare = p.pick("bare_account")
        prep = "in" if loc_only else p.pick("acc_prep_bare_ab", acc=bare)
        tail = [T(prep), T(bare)]

    # avoid "... current account currently"
    said = (measure + " " + " ".join(f[0] for f in tail)).lower()
    now_ok = [x for x in L.AB_NOW if not (x == "currently" and "current" in said)]
    noun = T("the " + measure + bal)
    if pattern == 1:
        frags = [T(verb), noun] + tail
    elif pattern == 2:
        frags = [T(verb), T("what the " + measure + bal + " is")] + tail
    elif pattern == 3:
        frags = [T(verb), T("how much is available")] + (tail or [T(p.pick("ab_now", now_ok))])
    elif pattern == 4:
        frags = [T(verb), T("the " + measure + "position")] + tail
    elif pattern == 5:
        frags = [T(verb), noun] + tail + [T(p.pick("ab_now", now_ok))]
    elif pattern == 6:
        frags = [T(verb), T("the funds available")] + (tail or [T(p.pick("ab_now", now_ok))])
    elif pattern == 7:
        frags = [T(verb), noun] + tail + [T(p.pick("ab_now", now_ok))]
    elif pattern == 8:
        frags = [T(verb), T("how much is left")] + (tail or [T(p.pick("ab_now", now_ok))])
    else:
        raise ValueError(pattern)
    return frags


AB_STANDALONE = [
    "Balance check - {C}.",
    "Quick question: {C}.",
    "Before I proceed, {C}.",
    "For my records, {C}.",
    "End of day check - {C}.",
]


# ==================================================================== driver
BUILDERS = {
    "NEW_PAYMENT": (build_new_payment, list(range(1, 11)), L.SHARED_FRAMES),
    "PAY_FROM_TEMPLATE": (build_pay_from_template, list(range(1, 9)), L.SHARED_FRAMES),
    "REPEAT_PAYMENT": (build_repeat_payment, list(range(1, 9)), L.SHARED_FRAMES),
    "ACCOUNT_BALANCE": (build_account_balance, list(range(1, 9)), L.SHARED_FRAMES),
}


def make_quotas(intent, rng):
    """Every balancer declares the margins it must stay uniform inside.

    `subset` is the strongest of these: keeping a value uniform within each
    entity-subset cell implies it is uniform against the presence of every
    other entity, which is the property that stops the model reading one slot
    off another.
    """
    ents = INTENT_ENTITIES[intent]
    half = N_PER_INTENT // 2
    q = {}
    B = lambda k, items, n, dims, counts=None: q.__setitem__(
        k, Balanced(items, n, rng, dims=dims, counts=counts, name=k))
    CORE = ("subset", "pattern", "frame")

    if "account" in ents:
        fam_counts = even_counts(L.ACCOUNT_FAMILIES, half)
        B("acc_family", None, None, CORE + ("trigger", "role"), fam_counts)
        for fam in L.ACCOUNT_FAMILIES:
            members = [(t, d) for t, d, f in L.ACCOUNTS if f == fam]
            B("acc_surf_" + fam, members, fam_counts[fam], CORE + ("trigger",))
        # "using" must introduce an account exactly as often as it introduces a
        # rail, a denomination or a template -> the trigger token carries no
        # information about which label follows it
        B("acc_prep", L.ACC_PREPS, half, CORE + ("role", "acc"),
          counts=L.trigger_counts(L.ACC_PREPS, half))
        B("acc_bare_mode", None, None, CORE, {"bare": 200, "none": 300})
        B("bare_account", L.BARE_ACCOUNT, 200, CORE)
        B("acc_prep_bare", L.ACC_PREPS, 200, CORE + ("acc",),
          counts=L.trigger_counts(L.ACC_PREPS, 200))
        B("acc_prep_bare_ab", L.AB_PREPS, 200, CORE + ("acc",))
    if "beneficiary" in ents:
        B("beneficiary", L.BENEFICIARIES, half, CORE + ("trigger", "role"))
        B("ben_prep", L.BEN_PREPS, half, CORE + ("ben",))
    if "amount" in ents:
        B("amount", L.AMOUNTS, half, CORE + ("has_ccy", "ctype"))
    if "currency" in ents:
        # joint (value, surface-class) draw, identical profile for all 5 codes
        pairs, counts = L.ccy_pair_counts(half)
        per_code = half // len(L.CCY_CODES)
        B("ccy_code", L.CCY_CODES, half,
          CORE + ("has_amount", "trigger", "amt", "co_labels"),
          counts=even_counts(L.CCY_CODES, half))
        for c in L.CCY_CODES:
            B("ccy_class_" + c, None, None, CORE + ("has_amount", "amt"),
              counts={t: counts[(c, t)] for t in ("code", "word", "sym")
                      if (c, t) in counts})
        for (c, t) in pairs:
            B("ccy_surf_%s_%s" % (c, t), L.CURRENCIES[c][t], counts[(c, t)], CORE)
        B("ccy_order", ["AC", "CA"], half, CORE + ("ctype",))
        B("ccy_trigger", L.CCY_TRIGGERS, half, CORE + ("ccy",),
          counts=L.trigger_counts(L.CCY_TRIGGERS, half, share=L.CCY_TRIGGER_SHARE))
    if "method" in ents:
        B("method", L.METHOD_CANONS, half, CORE + ("position", "trigger"),
          counts=even_counts(L.METHOD_CANONS, half))
        B("met_prep", L.MET_PREPS, half, CORE + ("canon", "position"),
          counts=L.trigger_counts(L.MET_PREPS, half))
        for c in L.METHOD_CANONS:
            forms = list(range(len(L.METHODS[c]["forms"])))
            # every rail gets the SAME case profile and the same share of the
            # pre-modifier slot; drawing forms from a cycle is what let UPI take
            # 7 pre-modifier slots while SWIFT took 1
            B("met_form_" + c, forms, half // len(L.METHOD_CANONS),
              CORE + ("position",))
    if "template_name" in ents:
        B("template", L.TEMPLATES, half, CORE + ("trigger", "role"))

    big = N_PER_INTENT
    add = lambda k, items, n=big, dims=CORE + ("ccy",): B(k, items, n, dims)
    if intent in ("NEW_PAYMENT", "REPEAT_PAYMENT"):
        B("now_suffix", None, None, CORE,
          counts=dict({"": 900}, **{x: 11 for x in L.AB_NOW if x != "in hand"}))
    if intent == "NEW_PAYMENT":
        add("np_vp_nominal", L.NP_VP_NOMINAL)
        add("np_vp_bare", L.NP_VP_BARE)
        add("np_vp_trans", list(L.NP_VP_TRANS))
        add("np_generic_head", L.NP_GENERIC_HEAD)
        add("np_pay_obj", ["the amount", "the dues", "the invoice"])
        for v, objs in L.NP_VP_TRANS.items():
            add("np_defobj_" + v, objs)
    elif intent == "PAY_FROM_TEMPLATE":
        B("pft_ref_named", L.PFT_REF_NAMED, half, CORE + ("tmpl",))
        B("pft_ref_anon", L.PFT_REF_ANON, half, CORE)
        add("pft_time", L.PFT_TIME_SUFFIX)
        add("pft_vp_use", L.PFT_VP_USE)
        add("pft_vp_run", L.PFT_VP_RUN)
        add("pft_vp_make", L.PFT_VP_MAKE)
        add("pft_vp_pay", L.PFT_VP_PAY)
        B("pft_trigger", L.PFT_TRIGGERS, half, CORE + ("tmpl",),
          counts=L.trigger_counts(L.PFT_TRIGGERS, half, share=L.PFT_TRIGGER_SHARE))
    elif intent == "REPEAT_PAYMENT":
        add("rp_adj", L.RP_ADJ)
        add("rp_time_pp", L.RP_TIME_PP)
        add("rp_clause", L.RP_CLAUSE)
        add("rp_asref", L.RP_ASREF)
        add("rp_vp_repeat", L.RP_VP_REPEAT)
        add("rp_vp_do", L.RP_VP_DO)
        add("rp_noun", L.RP_NOUN)
    else:
        add("ab_verb", L.AB_VERBS)
        add("ab_measure", L.AB_MEASURES)
        B("ab_prep", L.AB_PREPS, half, CORE + ("acc",))
        add("ab_bal_noun", L.AB_BAL_NOUN)
        add("ab_now", L.AB_NOW)
    return q


def relocate(text, spans):
    out, cursor = [], {}
    for sp in sorted(spans, key=lambda s: s["start"]):
        start = text.find(sp["text"], cursor.get(sp["text"], 0))
        assert start >= 0, (text, sp)
        cursor[sp["text"]] = start + 1
        out.append({"label": sp["label"], "text": sp["text"],
                    "start": start, "end": start + len(sp["text"])})
    return out


def generate_intent(intent, rng):
    builder, patterns, standalones = BUILDERS[intent]
    plan = subset_plan(intent, rng)
    quotas = make_quotas(intent, rng)

    kinds = ["W"] * N_WRAPPED + ["S"] * N_STANDALONE
    rng.shuffle(kinds)
    # patterns and wrappers are themselves balanced against the entity subset,
    # so no skeleton ever correlates with which slots are filled
    extra = {
        "__pat__": Balanced(patterns, N_PER_INTENT, rng,
                            dims=("subset", "frame"), name="__pat__"),
        "__wrap__": Balanced(L.WRAPPERS, N_WRAPPED, rng,
                             dims=("subset", "pattern"), name="__wrap__"),
        "__sa__": Balanced(list(range(len(standalones))), N_STANDALONE, rng,
                           dims=("subset", "pattern"), name="__sa__"),
    }

    p = Picker(quotas, rng)
    seen, rows = set(), []

    for i in range(N_PER_INTENT):
        subset = plan[i]
        skey = ",".join(sorted(subset)) or "-"
        colab = ",".join(sorted(subset - {"currency"})) or "-"
        for attempt in range(200):
            base = {"intent": intent, "subset": skey, "frame": kinds[i],
                    "co_labels": colab}
            p.begin("you", **base)
            # a handful of short zero-entity frames have very few realisations;
            # once the space around them is exhausted, relax the margin term
            # rather than emit a duplicate sentence
            p.jitter = attempt > 20
            pat, act = extra["__pat__"].pick(base, jitter=p.jitter)
            p.note("__pat__", pat, act)
            base["pattern"] = pat
            if kinds[i] == "W":
                (pre, suf, person), act = extra["__wrap__"].pick(base, jitter=p.jitter)
                p.note("__wrap__", (pre, suf, person), act)
                sa_idx = None
            else:
                person, pre, suf = "you", None, None
                sa_idx, act = extra["__sa__"].pick(base, jitter=p.jitter)
                p.note("__sa__", sa_idx, act)
            p.person = person
            p.ctx = base

            core, spans = render(builder(p, subset, pat))
            if sa_idx is None:
                if pre == "":
                    core = core[0].upper() + core[1:]
                text, spans = pre + core + suf, shift(spans, len(pre))
            else:
                head, tailtxt = standalones[sa_idx].split("{C}")
                text, spans = head + core + tailtxt, shift(spans, len(head))
            text = " ".join(text.split())
            if text not in seen:
                break
            # only refund when we are actually going to redraw; refunding on the
            # last attempt while still emitting the sentence is what left one
            # surface at 0 draws and another at 6
            if attempt < 199:
                p.rollback(extra)
        seen.add(text)
        rows.append({"input": text, "intent": intent, "spans": relocate(text, spans),
                     "pattern": pat, "frame": kinds[i], "subset": sorted(subset)})
    return rows


def main():
    master = random.Random(SEED)
    all_rows = []
    for intent in INTENT_ORDER:
        rows = generate_intent(intent, random.Random(master.randrange(1 << 30)))
        all_rows += rows
        print(intent, len(rows))
    master.shuffle(all_rows)

    with open("raw.jsonl", "w", encoding="utf-8") as f:
        for r in all_rows:
            ent = {}
            for sp in r["spans"]:
                ent.setdefault(sp["label"], []).append(sp["text"])
            ent = {k: (v[0] if len(v) == 1 else v) for k, v in ent.items()}
            f.write(json.dumps({"input": r["input"], "intent": r["intent"],
                                "entities": ent}, ensure_ascii=False) + "\n")

    with open("raw_spans.jsonl", "w", encoding="utf-8") as f:
        for i, r in enumerate(all_rows):
            f.write(json.dumps({
                "id": "bank-%05d" % i,
                "input": r["input"],
                "intent": r["intent"],
                "schema": INTENT_ENTITIES[r["intent"]],
                "spans": r["spans"],
                "meta": {"pattern": r["pattern"], "frame": r["frame"], "subset": r["subset"]},
            }, ensure_ascii=False) + "\n")
    print("total", len(all_rows))


if __name__ == "__main__":
    main()
