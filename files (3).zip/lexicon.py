# -*- coding: utf-8 -*-
"""
lexicon.py -- all surface inventories for the banking intent/entity dataset.

Design rules enforced here (checked again in validate.py):
  R1. No beneficiary / template / account string may contain a closed-set
      currency or method surface as a standalone word.
  R2. Method surfaces appear ONLY in intents whose allowed-entity list
      contains "method" (currently NEW_PAYMENT only).
  R3. Currency surfaces appear ONLY inside a labelled span (either as a
      `currency` entity, or embedded inside an `account` name span).
  R4. Generic payment nouns/verbs ("transfer", "payment", "payout",
      "fresh payment", ...) are decoys: they are NEVER labelled.
"""

# --------------------------------------------------------------------------
# ACCOUNTS  (exactly 100 surfaces)
# det modes: "none" -> bare only | "opt" -> bare/my/our/the | "det" -> my/our/the
# --------------------------------------------------------------------------
BANKS = ["HDFC Bank", "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank",
         "State Bank of India", "IndusInd Bank", "Yes Bank", "Barclays",
         "HSBC", "Citibank", "Standard Chartered", "DBS"]

_BANK_TYPE_BANKS = BANKS[:5]
_BANK_TYPES = ["current account", "savings account", "business account",
               "corporate account"]   # 5 x 4 = 20, one full family

NAMED_ACCOUNTS = [
    "Payroll Account", "Operations Account", "Treasury Account", "Escrow Account",
    "Vendor Settlement Account", "Petty Cash Account", "Corporate Card Account",
    "Collections Account", "Nostro Account", "Reserve Account",
    "Marketing Budget Account", "Rent Account", "Tax Account",
    "Import Settlement Account", "Export Proceeds Account",
    "Payroll Operating Account", "Branch Suspense Account", "Client Trust Account",
    "Project Alpha Account", "Subsidiary Account",
]

# purpose-qualified accounts whose NAME contains a denomination token.
# Per entities.json these belong to `account`, NOT `currency`.
CURRENCY_NAMED_ACCOUNTS = [
    "USD Trade Account", "EUR Settlement Account", "GBP Nostro Account",
    "SGD Operating Account", "INR Payables Account", "USD Collections Account",
    "EUR Payables Account", "GBP Current Account", "SGD Trade Account",
    "INR Salary Account", "USD Nostro Account", "EUR Operating Account",
    "GBP Settlement Account", "SGD Payables Account", "INR Escrow Account",
]
# which currency code is embedded, so we never emit that same code as a
# `currency` entity in the same sentence (avoids ambiguous duplicate strings)
ACCOUNT_EMBEDDED_CCY = {a: a.split()[0] for a in CURRENCY_NAMED_ACCOUNTS}

MASKED_ACCOUNTS = [
    "account ending 4471", "account ending 8890", "account ending in 2291",
    "account ending in 6708", "A/C XXXX4471", "account number 50100234567890",
    "account no. 91827364550", "account ending 0042", "account ending 3356",
    "account ending in 7712", "A/C ending 9903", "account XXXX1145",
    "savings account ending 5520", "current account ending 6641",
    "account number 004410098231",
]

TYPE_ACCOUNTS = ["current account", "savings account", "salary account",
                 "business account", "checking account", "operating account",
                 "corporate account", "joint account"]


BANKS = BANKS + ["Punjab National Bank", "Bank of Baroda", "Canara Bank",
                 "Union Bank of India", "NatWest", "Lloyds Bank",
                 "Santander", "Deutsche Bank"]
assert len(BANKS) == 20

# Each family holds EXACTLY 20 surfaces and receives EXACTLY 100 draws per
# intent, so every account string is drawn 5 times -- per-surface parity and
# per-family parity at the same time. Ragged inventories were what let some
# beneficiaries appear 10x and others 8x while the totals still looked right.
NAMED_ACCOUNTS = NAMED_ACCOUNTS[:12] + TYPE_ACCOUNTS
CURRENCY_NAMED_ACCOUNTS = CURRENCY_NAMED_ACCOUNTS + [
    "INR Payroll Account", "GBP Vendor Account", "SGD Operations Account",
    "USD Reserve Account", "SGD Escrow Account"]
MASKED_ACCOUNTS = MASKED_ACCOUNTS + [
    "account ending 2288", "A/C XXXX7710", "account number 60110455120034",
    "account ending in 1409", "A/C ending 8025"]
# rebuilt AFTER the extension: a denomination inside an account name must block
# that same denomination from also being emitted as a currency entity, or the
# sentence contains one string under two labels and the span is unresolvable
ACCOUNT_EMBEDDED_CCY = {a: a.split()[0] for a in CURRENCY_NAMED_ACCOUNTS}


def _build_accounts():
    out = []
    for b in BANKS:
        out.append((b, "none", "bank_name"))
    for b in _BANK_TYPE_BANKS:
        for t in _BANK_TYPES:
            out.append(("%s %s" % (b, t), "opt", "bank_plus_type"))
    for a in NAMED_ACCOUNTS:
        out.append((a, "det" if a in TYPE_ACCOUNTS else "opt", "named"))
    for a in CURRENCY_NAMED_ACCOUNTS:
        out.append((a, "opt", "ccy_named"))
    for a in MASKED_ACCOUNTS:
        out.append((a, "opt", "masked"))
    return out


ACCOUNTS = _build_accounts()          # list[(text, det_mode, family)]
assert len(ACCOUNTS) == 100
ACCOUNT_FAMILIES = ["bank_name", "bank_plus_type", "named", "ccy_named", "masked"]

# non-identifying account wording: the head noun alone distinguishes nothing,
# so per entities.json it is NOT an account entity. These are hard negatives.
BARE_ACCOUNT = ["my account", "the account", "my bank account", "our account",
                "the same account"]
ACCOUNT_DETS = {"none": [""], "opt": ["", "my", "our", "the"], "det": ["my", "our", "the"]}

# --------------------------------------------------------------------------
# BENEFICIARIES (exactly 100)
# --------------------------------------------------------------------------
BENEFICIARIES = [
    # persons
    "Rahul Sharma", "Priya Nair", "Anjali Mehta", "Vikram Singh", "Sneha Kulkarni",
    "Arjun Reddy", "Neha Gupta", "Karan Malhotra", "Divya Iyer", "Rohit Verma",
    "Meera Krishnan", "Sanjay Patel", "Aditi Rao", "Manish Agarwal", "Pooja Desai",
    "James Whitfield", "Emily Carter", "Michael O'Brien", "Sarah Lindqvist",
    "Thomas Muller", "Laura Bennett", "Daniel Foster", "Hannah Weiss",
    "Peter Novak", "Claire Dubois", "Wei Chen", "Aisha Rahman", "Tomas Silva",
    "Elena Petrova", "Yuki Tanaka",
    # organisations
    "Acme Industries", "Bluewave Logistics", "Sterling Textiles Pvt Ltd",
    "Orchid Pharma Ltd", "Redstone Consulting", "Nimbus Software Solutions",
    "Greenfield Agro Exports", "Vertex Engineering", "Harbour Freight Services",
    "Lotus Interiors", "Quantum Analytics LLP", "Silverline Media",
    "Cobalt Industries GmbH", "Maple Leaf Trading", "Ironwood Constructions",
    "Zenith Facility Services", "Crestview Properties", "Pinnacle Staffing",
    "Northgate Supplies", "Tidewater Marine Services", "Falcon Auto Components",
    "Emerald Foods Ltd", "Anchor Legal Associates", "Brightpath Education Trust",
    "Summit Insurance Brokers", "Delta Chemicals Inc", "Cascade Water Systems",
    "Onyx Security Services", "Trident Packaging", "Larkspur Design Studio",
    "Everest Steel Works", "Hillcrest Dairy Farms", "Mercury Courier Services",
    "Blue Orchid Hospitality", "Kingsley Publishing", "Amber Electricals",
    "Riverside Warehousing", "Copperfield Machinery", "Lakeside Hotels Pvt Ltd",
    "Solaris Energy Systems", "Windrose Aviation Services", "Stonebridge Realty",
    "Fernwood Timber Co", "Highland Beverages", "Aurora Diagnostics",
    "Kestrel Marketing Group", "Beacon Tech Labs", "Palmgrove Resorts",
    "Ridgeline Apparel", "Corvus Data Systems", "Thornfield Estates",
    "Vantage Legal Services", "Meridian Shipping Lines", "Alder Grove Nurseries",
    "Pacific Rim Traders", "Granite Peak Mining", "Willowbrook Foods",
    "Skyline Interiors LLP", "Halcyon Travel Services", "Fairmont Cleaning Co",
    "Norsk Marine AS", "Bellweather Fabrics", "Juniper Health Services",
    "Oakridge Motors", "Nova Print Works", "Cinnamon Bay Spices",
    "Trailhead Outdoor Gear", "Silver Birch Stationers", "Quarry Lane Builders",
    "Ashford Pharmaceuticals",
]

# --------------------------------------------------------------------------
# TEMPLATE NAMES (exactly 50)
# --------------------------------------------------------------------------
TEMPLATES = [
    "Monthly Rent", "Vendor Settlement Weekly", "Payroll Batch", "Office Rent",
    "Utility Bills", "Q3 Vendor Settlement", "Landlord Dues", "Insurance Premium",
    "Electricity Bill", "Tuition Fee", "Warehouse Lease", "Annual Audit Fee",
    "Weekly Contractor Dues", "Home Loan EMI", "Society Maintenance",
    "Distributor Settlement", "Marketing Retainer", "Freight Charges",
    "Supplier Advance", "Quarterly Dividend", "Staff Reimbursement",
    "Courier Charges", "Cloud Hosting Bill", "Legal Retainer", "Security Services",
    "Housekeeping Bill", "Internet Bill", "Water Charges", "Property Tax",
    "Vendor Advance", "Monthly Subscription", "Equipment Lease", "Consultant Fee",
    "Travel Reimbursement", "Canteen Bill", "Transport Charges",
    "Maintenance Contract", "Software Licence Renewal", "Printing Charges",
    "Raw Material Purchase", "Export Commission", "Franchise Fee",
    "Membership Renewal", "Training Fee", "Medical Reimbursement",
    "Fuel Card Settlement", "Parking Charges", "Advertising Spend",
    "Vendor Retainer", "Site Rent",
]

# --------------------------------------------------------------------------
# AMOUNTS (exactly 60: 48 numeric, 12 spelled)
# min value 75 so nothing collides with day-of-month decoys (1..31)
# --------------------------------------------------------------------------
AMOUNTS_DIGIT = [
    "75", "120", "250", "480", "500", "750", "900", "1,000", "1,200", "1,500",
    "1,750", "2,000", "2,500", "3,000", "3,500", "4,000", "4,500", "5,000",
    "6,000", "7,500", "8,200", "9,000", "10,000", "12,000", "12,500", "15,000",
    "18,000", "20,000", "22,500", "25,000", "30,000", "35,000", "40,000",
    "45,000", "50,000", "60,000", "65,000", "75,000", "80,000", "90,000",
    "100,000", "125,000", "150,000", "200,000", "250,000",
    "1250.75", "3499.50", "899.99",
]
AMOUNTS_WORD = [
    "five hundred", "seven hundred fifty", "one thousand", "twelve hundred",
    "two thousand", "twenty five hundred", "five thousand", "ten thousand",
    "fifteen thousand", "twenty thousand", "fifty thousand", "one lakh",
]
AMOUNTS = AMOUNTS_DIGIT + AMOUNTS_WORD

# --------------------------------------------------------------------------
# CURRENCY (closed set, 5 values)
#   code  -> works in "500 USD" / "USD 500" / "in USD" / "a USD payment"
#   word  -> works in "500 dollars" / "in dollars"
#   sym   -> works ONLY as "$500" (needs an amount)
# --------------------------------------------------------------------------
CURRENCIES = {
    "INR": {"code": ["INR"], "word": ["rupees", "Indian rupees"], "sym": ["\u20b9"], "art": "an"},
    "USD": {"code": ["USD"], "word": ["dollars", "US dollars"], "sym": ["$"], "art": "a"},
    "EUR": {"code": ["EUR"], "word": ["euros"], "sym": ["\u20ac"], "art": "a"},
    "GBP": {"code": ["GBP"], "word": ["pounds", "British pounds"], "sym": ["\u00a3"], "art": "a"},
    "SGD": {"code": ["SGD"], "word": ["Singapore dollars"], "sym": ["S$"], "art": "an"},
}
CCY_CODES = list(CURRENCIES.keys())

# --------------------------------------------------------------------------
# METHOD (closed set, 13 values)
# `forms` -> [labelled_span, *unlabelled_tail_tokens]
#   "NEFT transfer" teaches that the tail word "transfer" is NOT part of the
#   rail; "bank transfer" teaches that the same word IS part of it when the
#   whole bigram is a member of the closed set.
# `art`/`head` are used by the adjectival pattern ("make a NEFT payment ...").
# --------------------------------------------------------------------------
METHODS = {
    "CHAPS":           {"forms": [["CHAPS"], ["CHAPS", "payment"], ["CHAPS", "transfer"], ["chaps"]], "art": "a",  "head": "payment"},
    "SWIFT":           {"forms": [["SWIFT"], ["SWIFT", "transfer"], ["SWIFT", "payment"], ["swift"]], "art": "a",  "head": "payment"},
    "SEPA":            {"forms": [["SEPA"], ["SEPA", "transfer"], ["SEPA", "payment"], ["sepa"]],     "art": "a",  "head": "transfer"},
    "ACH":             {"forms": [["ACH"], ["ACH", "transfer"], ["ACH", "payment"], ["ach"]],         "art": "an", "head": "payment"},
    "Faster Payments": {"forms": [["Faster Payments"], ["faster payments"], ["Faster Payments", "transfer"]], "art": "a", "head": "transfer"},
    "wire transfer":   {"forms": [["wire transfer"]],     "art": "a",  "head": None},
    "bank transfer":   {"forms": [["bank transfer"]],     "art": "a",  "head": None},
    "online transfer": {"forms": [["online transfer"]],   "art": "an", "head": None},
    "internal transfer": {"forms": [["internal transfer"]], "art": "an", "head": None},
    "NEFT":            {"forms": [["NEFT"], ["NEFT", "transfer"], ["NEFT", "payment"], ["neft"]],     "art": "a",  "head": "transfer"},
    "RTGS":            {"forms": [["RTGS"], ["RTGS", "transfer"], ["rtgs"]],                          "art": "an", "head": "payment"},
    "IMPS":            {"forms": [["IMPS"], ["IMPS", "transfer"], ["imps"]],                          "art": "an", "head": "transfer"},
    "UPI":             {"forms": [["UPI"], ["UPI", "transfer"], ["UPI", "payment"], ["upi"]],         "art": "a",  "head": "payment"},
}
METHOD_CANONS = list(METHODS.keys())

# --------------------------------------------------------------------------
# SHARED WRAPPERS -- identical inventory for all four intents (register /
# politeness / modality). Each wrapper takes a BASE-FORM verb phrase.
# --------------------------------------------------------------------------
WRAPPERS = [
    ("", ".", "you"),                # bare imperative (core is capitalised)
    ("Please ", ".", "you"),
    ("Can you ", "?", "you"),
    ("Could you ", "?", "you"),
    ("Would you ", "?", "you"),
    ("I need to ", ".", "first"),
    ("I want to ", ".", "first"),
    ("I would like to ", ".", "first"),
    ("I'd like you to ", ".", "you"),
    ("Kindly ", ".", "you"),
    ("Help me ", ".", "first"),
    ("We need to ", ".", "first"),
    ("Let's ", ".", "first"),
    ("Go ahead and ", ".", "you"),
    ("Is it possible to ", "?", "you"),
    ("Can we ", "?", "first"),
    ("Requesting you to ", ".", "you"),
    ("Just ", ".", "you"),
    ("Urgent - ", ".", "you"),
    ("First thing today, ", ".", "you"),
]

# --------------------------------------------------------------------------
# NEW_PAYMENT verb phrases -- every one of these is a DECOY for `method`
# --------------------------------------------------------------------------
NP_VP_NOMINAL = [
    "make a payment", "initiate a payment", "process a payment", "set up a payment",
    "raise a payment", "create a payment", "book a payment", "arrange a payment",
    "issue a payment", "put through a payment", "make a fresh payment",
    "start a new payment", "make a transfer", "do a transfer",
    "set up a fresh transfer", "action a payment", "make a one-off payment",
    "organise a payment",
]
NP_VP_BARE = ["make", "initiate", "process", "set up", "raise", "book",
              "arrange", "put through", "organise", "create", "action"]
NP_VP_TRANS = {
    "send":     ["money", "funds", "a payment", "the funds"],
    "transfer": ["funds", "money", "the funds", "the amount"],
    "remit":    ["funds", "money", "the amount"],
    "move":     ["funds", "money", "the funds"],
    "push":     ["funds", "money", "the funds"],
    "credit":   ["funds", "the amount", "money"],
    "release":  ["funds", "the funds", "the payment"],
}
NP_GENERIC_HEAD = ["payment", "transfer"]

BEN_PREPS = ["to", "in favour of", "for", "payable to"]
ACC_PREPS = ["from", "out of", "using", "debiting", "against"]
MET_PREPS = ["via", "through", "using", "by"]

# --------------------------------------------------------------------------
# PAY_FROM_TEMPLATE wording
# --------------------------------------------------------------------------
PFT_REF_NAMED = [
    "the {T} template", "my {T} template", "the template named {T}",
    "the saved template {T}", "the {T} payment template",
    "the stored template called {T}", "template {T}", "the {T} setup",
    "the saved {T} setup", "my {T} payee template",
]
PFT_REF_ANON = [
    "the saved template", "my saved template", "the stored payment template",
    "the predefined template", "the existing payment setup",
    "my saved payment setup", "the payment template I have saved",
    "one of my saved templates", "the setup I use for recurring payments",
    "the template that is already set up",
]
# One time vocabulary for both PAY_FROM_TEMPLATE and REPEAT_PAYMENT. Sharing
# only four of the eleven phrases left "yesterday" and "quarter" as 100% RP
# cues; a saved setup can just as well be "from last quarter" as a past
# payment can. "with reference TXN..." stays RP-only and is semantically
# earned: a transaction reference identifies an executed payment, which is the
# definition of REPEAT_PAYMENT.
SHARED_TIME = ["from last month", "from yesterday", "from last week",
               "from 12 March", "from last Tuesday", "from this morning",
               "from the 3rd", "from last quarter", "from earlier today",
               "from a while back"]
PFT_TIME_SUFFIX = ["", "", "", "", "", "", "", ""] + SHARED_TIME
PFT_VP_USE = ["use", "apply", "pull up", "load", "select", "pick"]
PFT_VP_RUN = ["run", "trigger", "execute", "fire", "process"]
PFT_VP_MAKE = ["make a payment", "initiate a payment", "process a payment",
               "raise a payment", "send a payment", "create a payment",
               "set up a payment", "put through a payment"]
PFT_VP_PAY = ["pay", "send", "release", "remit"]

# --------------------------------------------------------------------------
# REPEAT_PAYMENT wording
# --------------------------------------------------------------------------
# determiner is baked in so possessives never collide with a leading "the"
RP_ADJ = ["the last", "the previous", "the earlier", "the most recent",
          "the original", "the recent", "last month's", "yesterday's",
          "last week's"]
RP_TIME_PP = SHARED_TIME + ['with reference TXN88213']
RP_CLAUSE = ["I made last month", "I made yesterday", "I did last week",
             "we sent last quarter", "that went out yesterday",
             "that I authorised last week"]
RP_ASREF = ["as last time", "as before", "as the previous one",
            "like last time", "as we did earlier"]
RP_VP_REPEAT = ["repeat", "resend", "redo", "rerun", "reissue", "replay",
                "reprocess", "recreate", "duplicate", "copy"]
RP_VP_DO = ["make", "process", "run", "put through", "raise"]
RP_NOUN = ["payment", "transfer", "transaction", "instruction"]

# --------------------------------------------------------------------------
# ACCOUNT_BALANCE wording
# --------------------------------------------------------------------------
AB_VERBS_NEUTRAL = ["check", "get", "look up", "confirm", "pull up", "fetch",
                    "display", "verify", "find out", "report", "review"]
AB_VERBS_ME = ["show me", "tell me", "let me know", "give me"]   # need a "you" wrapper
AB_VERBS = AB_VERBS_NEUTRAL + AB_VERBS_ME
AB_MEASURES = ["", "available ", "current ", "ledger ", "closing ", "opening ",
               "cleared ", "book ", "running ", "net "]
AB_PREPS = ["in", "of", "for", "on", "held in", "from"]
# fixed per-pattern tails ("as of now" on every pattern-5 sentence) make the
# time phrase a pattern fingerprint; drawing from one shared, balanced pool
# removes that and widens the zero-entity space enough to avoid collisions
AB_NOW = ["as of now", "at the moment", "right now", "currently", "today",
          "as things stand", "as of today", "at present", "in hand",
          "as of this morning"]
AB_PREPS_LOC = ["in"]                   # "available in X" / "left in X"
AB_BAL_NOUN = ["balance", "balance figure", "balance amount"]


# ==========================================================================
# INVENTORY SIZING -- every open set must divide its per-intent budget exactly
# ==========================================================================
# Budget is 500 draws per intent per slot. 500/112 = 4.46 meant 52 beneficiaries
# were drawn 5 times and 60 were drawn 4 -- a 25% per-value skew invisible in
# the totals. Sizes below all divide 500: accounts 100 (x5), beneficiaries
# 125 (x4), templates 100 (x5), amounts 100 (x5), currencies 5 (x100).
BENEFICIARIES = BENEFICIARIES + [
    "Westford Ceramics", "Blackthorn Logistics Ltd", "Sunfield Textiles",
    "Cobblestone Interiors", "Marlow Precision Tools",
]
TEMPLATES = TEMPLATES + [
    "Vendor Payout Monthly", "Office Cleaning Bill", "Server Hosting Fee",
    "Branch Rent", "Fuel Reimbursement", "Annual Licence Fee",
    "Contractor Weekly Dues", "Stationery Purchase", "Pest Control Charges",
    "Lift Maintenance", "Generator Diesel Bill", "Broadband Renewal",
    "Payroll Contractors", "Retainer Fee Q1", "Warehouse Utilities",
    "Advance Against Order", "Customs Clearance Fee", "Logistics Settlement",
    "Data Centre Charges", "Recruitment Fee", "Sponsorship Payment",
    "Club Membership Dues", "Municipal Charges", "Vendor Retention Payout",
    "Machinery AMC", "Export Freight Bill", "Packaging Supplies",
    "Consultancy Retainer", "Fire Safety Audit", "Fleet Insurance",
]
AMOUNTS_DIGIT = AMOUNTS_DIGIT + [
    "76", "84", "96", "115", "135", "165", "185", "225", "275", "325",
    "375", "425", "475", "525", "575", "625", "725", "825", "925", "1,150",
    "1,350", "1,850", "2,250", "3,750", "4,250", "6,500", "8,750", "11,500",
    "17,500", "28,500", "37,500", "62,500",
]
AMOUNTS_WORD = AMOUNTS_WORD + [
    "eighty five", "one hundred twenty", "three hundred fifty",
    "seven hundred", "eighteen hundred", "four thousand five hundred",
    "sixty thousand", "two hundred thousand",
]
AMOUNTS = AMOUNTS_DIGIT + AMOUNTS_WORD

# ==========================================================================
# ROLE AMBIGUITY  -- deliberately breaking the string/label bijection
# ==========================================================================
# The first build kept the account, beneficiary and template inventories 100%
# string-disjoint. That is a latent shortcut: an encoder can memorise
# "Acme Industries => beneficiary" and never learn to read the role off the
# context. In production every new payee is an unseen string, so a model that
# memorised the inventory degrades exactly where it matters.
#
# These pools give a controlled share of surfaces more than one legitimate
# role, so the label has to come from the syntax:
#   "pay HDFC Bank"        -> beneficiary   (a bank can be a payee: loan, card)
#   "from HDFC Bank"       -> account       (the same string, funding source)
#   "the Payroll Batch template" -> template_name
#   "pay Payroll Batch"    -> not a payee; purposes are excluded by definition,
#                             so shared strings are drawn from ORGS only.
DUAL_BANK = list(BANKS)                    # all 20: account <-> beneficiary
DUAL_ORG = [
    "Acme Industries", "Bluewave Logistics", "Redstone Consulting",
    "Vertex Engineering", "Harbour Freight Services", "Silverline Media",
    "Maple Leaf Trading", "Zenith Facility Services", "Northgate Supplies",
    "Falcon Auto Components", "Summit Insurance Brokers", "Trident Packaging",
    "Mercury Courier Services", "Kingsley Publishing", "Nova Print Works",
    "Meridian Shipping Lines", "Pacific Rim Traders", "Willowbrook Foods",
    "Juniper Health Services", "Oakridge Motors",
]                                          # beneficiary <-> template_name
assert all(o in BENEFICIARIES for o in DUAL_ORG)

# templates keep their 50 purpose names AND gain the 20 org names, so a
# template_name span is sometimes a purpose and sometimes an organisation --
# the model cannot use "looks like a company" as a template/beneficiary cue
TEMPLATES = TEMPLATES + DUAL_ORG

# a bank string may fill the account slot or the beneficiary slot; never both
# in one sentence (enforced in generate.py)
BENEFICIARIES = BENEFICIARIES + DUAL_BANK


# ==========================================================================
# TRIGGER BUDGETS
# ==========================================================================
# "use / using" was resolving to method 127x, template 100x, account 100x but
# currency only 29x. Any trigger whose posterior over labels is lopsided
# becomes a shortcut. Extraction is intent-conditioned, so the requirement is
# that within EACH intent the shared trigger introduces every label that intent
# allows an identical number of times.
SHARED_TRIGGER = "using"
TRIGGER_SHARE = 60          # occurrences per label per intent, at half=500

CCY_TRIGGERS = ["in", "using", "denominated in"]
# only ~half of currency draws take a preposition (the rest are juxtaposed
# with the amount), and only ~half of template draws carry a real name, so
# these budgets are scaled up to land TRIGGER_SHARE hits on a labelled span
CCY_TRIGGER_SHARE = 100
PFT_TRIGGER_SHARE = 160
PFT_TRIGGERS = ["from", "using", "based on"]


def trigger_counts(items, total, base=500, share=TRIGGER_SHARE):
    """Pin the shared trigger to a fixed budget and split the rest evenly, so
    P(label | 'using') is flat inside every intent."""
    items = list(items)
    if SHARED_TRIGGER not in items:
        return even_counts_local(items, total)
    n = max(1, round(share * total / base))
    rest = total - n
    others = [i for i in items if i != SHARED_TRIGGER]
    base_c, rem = divmod(rest, len(others))
    out = {SHARED_TRIGGER: n}
    for i, it in enumerate(others):
        out[it] = base_c + (1 if i < rem else 0)
    return out


def even_counts_local(items, total):
    items = list(items)
    b, r = divmod(total, len(items))
    return {it: b + (1 if i < r else 0) for i, it in enumerate(items)}


# ==========================================================================
# CURRENCY: value x surface-class budget
# ==========================================================================
# Identical profile for all five values. Symbols are only grammatical with a
# digit amount, so they get a smaller share -- but the SAME smaller share for
# every currency, which is the property that matters.
CCY_FORM_MIX = {"code": 0.40, "word": 0.40, "sym": 0.20}


def ccy_pair_counts(total):
    per_code = total // len(CCY_CODES)
    pairs, counts = [], {}
    for c in CCY_CODES:
        for t, frac in CCY_FORM_MIX.items():
            if not CURRENCIES[c].get(t):
                continue
            pairs.append((c, t))
            counts[(c, t)] = int(round(per_code * frac))
    return pairs, counts


# ==========================================================================
# INTEGRITY ASSERTIONS -- a duplicate entry collapses the balancer's key set,
# shrinking its budget and letting the surplus escape through the
# exhausted-candidate fallback. That is precisely how one value ends up drawn
# 6 times and another 0 while the totals still add up. Fail loudly instead.
# ==========================================================================
def _assert_exact(name, items, budget=500):
    assert len(items) == len(set(items)), \
        "%s contains duplicates: %s" % (name, [k for k in items if items.count(k) > 1])
    assert budget % len(items) == 0, \
        "%s has %d entries; %d is not divisible by it" % (name, len(items), budget)


_assert_exact("ACCOUNTS", [a for a, _, _ in ACCOUNTS])
_assert_exact("BENEFICIARIES", BENEFICIARIES)
_assert_exact("TEMPLATES", TEMPLATES)
_assert_exact("AMOUNTS", AMOUNTS)
for _fam in ACCOUNT_FAMILIES:
    _members = [a for a, _, f in ACCOUNTS if f == _fam]
    _assert_exact("account family " + _fam, _members, 500 // len(ACCOUNT_FAMILIES))


# ==========================================================================
# SHARED STANDALONE FRAMES
# ==========================================================================
# The first build gave each intent its own five opening frames. That put a
# 100%-purity intent cue on the leading 2-4 tokens of 20% of the corpus --
# and worse, the cue was carried by semantically NEUTRAL wording ("Before I
# proceed,", "For my records,") that a model has no business associating with
# any intent. Frames that merely restate the intent ("Balance check -",
# "Template payment:") are dropped: their signal duplicates the intent's own
# vocabulary inside the sentence, so they cost nothing and gave everything.
# One pool, used identically by all four intents, 20 uses each per intent.
SHARED_FRAMES = [
    "Action needed - {C}.",
    "Quick question: {C}.",
    "Before I proceed, {C}.",
    "For my records, {C}.",
    "End of day check - {C}.",
    "Quick one - {C}.",
    "When you get a chance, {C}.",
    "Priority request: {C}.",
    "Following up - {C}.",
    "Small ask: {C}.",
]
